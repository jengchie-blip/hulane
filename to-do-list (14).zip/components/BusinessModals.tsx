
import React, { useState, useEffect, useMemo } from 'react';
import { 
  AlertTriangle, ArrowRightLeft, CheckCircle2, Trash2, Plus, 
  ArrowUp, ArrowDown, Info, Search, X, Pencil, Save, ScrollText, 
  Settings, Microscope, Tag, PenTool, Calendar, Clock, RotateCcw,
  User as UserIcon, BarChart3, Battery, BatteryWarning, BatteryCharging,
  Briefcase, Zap, PieChart, TrendingUp, Target, Activity
} from 'lucide-react';
import { User, Task, Role, TaskPriority, ProjectPhase, Category, TaskLog, DateChangeRequest } from '../types';
import { Button, Modal, ConfirmModal, StatusBadge, getIconComponent, UserAvatar, CATEGORY_ICONS, USER_AVATAR_ICONS } from './Shared';
import { getPhaseLabel, getStatusLabel, generateId } from '../utils';
import { AVATAR_COLORS } from '../constants';

// Constants for Dropdowns
const CHANGE_CATEGORY_OPTIONS = [
  "設計預留",
  "設計錯誤",
  "圖面誤記",
  "尺寸設計調整",
  "客戶需求變更"
];

const CHANGE_ANALYSIS_OPTIONS = [
  "測繪錯誤",
  "未落實設計點檢",
  "新設計結構，未做好預留",
  "結構點檢缺漏"
];

// Helper to parse YYYY-MM-DD as Local Midnight Date
const parseDateLocal = (dateStr: string) => {
  if (!dateStr) return new Date(0); // Invalid fallback
  const [y, m, d] = dateStr.split('-').map(Number);
  return new Date(y, m - 1, d);
};

export const getCategoryIconComponent = (iconName?: string) => {
  return getIconComponent(iconName, "w-4 h-4");
};

// --- Shared Components ---

interface TaskItemProps { 
  task: Task; 
  categories: Category[]; 
  showOwner?: boolean; 
  users?: User[]; 
  onClick?: () => void;
  onEdit?: () => void;
  onDelete?: () => void;
  onTransfer?: () => void; // Added onTransfer prop
  showLogsToggle?: boolean;
}

export const TaskItem: React.FC<TaskItemProps> = ({ 
  task, 
  categories, 
  showOwner, 
  users, 
  onClick,
  onEdit,
  onDelete,
  onTransfer,
  showLogsToggle = false
}) => {
  const [showLogs, setShowLogs] = useState(false);
  const cat = categories.find(c => c.id === task.categoryId);
  const owner = users?.find(u => u.id === task.userId);

  return (
    <div 
      className={`p-3 border rounded-lg mb-2 transition-colors bg-white ${onClick ? 'cursor-pointer hover:bg-slate-50' : ''}`}
      onClick={onClick}
    >
       <div className="flex justify-between items-start">
         <div className="flex items-center gap-2 flex-1">
            <StatusBadge status={task.status} />
            <span className="font-bold text-slate-800 line-clamp-1">{task.title}</span>
         </div>
         <div className="flex items-center gap-2 shrink-0">
            {task.deadline && (
                <span className={`text-xs whitespace-nowrap ${new Date(task.deadline) < new Date() && task.status !== 'DONE' ? 'text-red-500 font-bold' : 'text-slate-500'}`}>
                    {task.deadline}
                </span>
            )}
            
            {(onEdit || onDelete || showLogsToggle || onTransfer) && (
              <div className="flex items-center gap-1 border-l pl-2 ml-1" onClick={e => e.stopPropagation()}>
                {showLogsToggle && task.logs.length > 0 && (
                   <button 
                     onClick={() => setShowLogs(!showLogs)} 
                     className={`p-1.5 rounded hover:bg-slate-100 ${showLogs ? 'text-blue-600 bg-blue-50' : 'text-slate-400'}`} 
                     title="查看日誌"
                   >
                     <ScrollText className="w-3.5 h-3.5" />
                   </button>
                )}
                {onTransfer && (
                  <button onClick={onTransfer} className="p-1.5 text-slate-400 hover:text-blue-600 hover:bg-slate-100 rounded" title="轉派任務">
                    <ArrowRightLeft className="w-3.5 h-3.5" />
                  </button>
                )}
                {onEdit && (
                  <button onClick={onEdit} className="p-1.5 text-slate-400 hover:text-blue-600 hover:bg-slate-100 rounded" title="編輯">
                    <Pencil className="w-3.5 h-3.5" />
                  </button>
                )}
                {onDelete && (
                  <button onClick={onDelete} className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded" title="刪除">
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            )}
         </div>
       </div>
       
       <div className="flex gap-3 mt-2 text-xs text-slate-500 items-center flex-wrap">
           <span className="flex items-center gap-1" title={cat?.note || ''}>
             {getCategoryIconComponent(cat?.icon)} 
             {cat?.name || '未分類'}
             {cat?.note && <Info className="w-3 h-3 text-blue-400" />}
           </span>
           <span className="flex items-center gap-1"><Tag className="w-3 h-3" /> {task.priority}</span>
           <span className="flex items-center gap-1"><Tag className="w-3 h-3" /> {task.partNumber || 'N/A'}</span>
           {showOwner && owner && (
             <span className="flex items-center gap-1 pl-2 border-l border-slate-200">
               <UserAvatar user={owner} size="sm" /> 
               {owner.name}
             </span>
           )}
           {/* Display DV stats if available */}
           {task.dvCount !== undefined && task.dvCount > 0 && (
             <span className="flex items-center gap-1 text-indigo-600 font-medium bg-indigo-50 px-1.5 rounded">
               <Microscope className="w-3 h-3" />
               設計成功率: {Math.round((task.dvAchieved || 0) / task.dvCount * 100)}% ({task.dvAchieved}/{task.dvCount})
             </span>
           )}
           {/* Display Change Order info if available */}
           {task.changeOrderNumber && (
              <span className="flex items-center gap-1 text-orange-600 font-medium bg-orange-50 px-1.5 rounded">
                <RotateCcw className="w-3 h-3" />
                {task.changeOrderNumber} (#{task.changeCount})
              </span>
           )}
       </div>

       {showLogs && task.logs.length > 0 && (
         <div className="mt-3 bg-slate-50 rounded border border-slate-100 p-2 space-y-2 animate-in fade-in zoom-in-95" onClick={e => e.stopPropagation()}>
            <div className="text-xs font-bold text-slate-400 uppercase">工作日誌 ({task.logs.length})</div>
            {task.logs.sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime()).map(log => (
              <div key={log.id} className="text-xs border-l-2 border-slate-300 pl-2">
                <div className="flex justify-between text-slate-500 mb-0.5">
                  <span>{log.date}</span>
                  <span>{log.hoursSpent}h</span>
                </div>
                <div className="text-slate-700">{log.content}</div>
              </div>
            ))}
         </div>
       )}
    </div>
  )
};

// --- Modals ---

export const UserModal = ({ 
  isOpen, 
  onClose, 
  onSubmit, 
  editingUser,
  currentUser 
}: { 
  isOpen: boolean; 
  onClose: () => void; 
  onSubmit: (data: any) => void; 
  editingUser: User | null;
  currentUser?: User;
}) => {
  const [formData, setFormData] = useState<Partial<User>>({ 
    name: '', employeeId: '', role: 'ENGINEER', avatarColor: 'bg-blue-500', avatarIcon: '', password: '' 
  });

  useEffect(() => {
    if (editingUser) {
      setFormData({ 
        name: editingUser.name, 
        employeeId: editingUser.employeeId, 
        role: editingUser.role, 
        avatarColor: editingUser.avatarColor,
        avatarIcon: editingUser.avatarIcon || '',
        password: editingUser.password || '' 
      });
    } else {
      setFormData({ name: '', employeeId: '', role: 'ENGINEER', avatarColor: 'bg-blue-500', avatarIcon: '', password: '' });
    }
  }, [editingUser, isOpen]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
    onClose();
  };

  const isAdmin = currentUser?.role === 'ADMIN';
  const isSelf = currentUser && editingUser && currentUser.id === editingUser.id;
  
  const disableSensitive = editingUser && !isAdmin;

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={editingUser ? '編輯成員資料' : '新增成員'} maxWidth="max-w-2xl">
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">姓名</label>
            <input required type="text" className="w-full p-2 border rounded-lg" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">工號</label>
            <input 
              required 
              type="text" 
              className={`w-full p-2 border rounded-lg ${disableSensitive ? 'bg-slate-100 text-slate-500 cursor-not-allowed' : ''}`}
              value={formData.employeeId} 
              onChange={e => setFormData({...formData, employeeId: e.target.value})} 
              disabled={!!disableSensitive}
            />
          </div>
        </div>
        
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">角色</label>
          <select 
             className={`w-full p-2 border rounded-lg ${disableSensitive ? 'bg-slate-100 text-slate-500 cursor-not-allowed' : ''}`}
             value={formData.role} 
             onChange={e => setFormData({...formData, role: e.target.value as Role})}
             disabled={!!disableSensitive}
          >
            <option value="ENGINEER">工程師 (Engineer)</option>
            <option value="ASSISTANT">助理 (Assistant)</option>
            <option value="ADMIN">主管 (Admin)</option>
          </select>
          {disableSensitive && <p className="text-xs text-slate-400 mt-1">僅主管可修改工號與角色權限</p>}
        </div>

        {/* Avatar Selection */}
        <div className="bg-slate-50 p-4 rounded-lg border border-slate-200">
           <label className="block text-sm font-medium text-slate-700 mb-3">設定頭像 (Icon & Color)</label>
           
           <div className="flex flex-col md:flex-row gap-6">
              {/* Preview */}
              <div className="flex flex-col items-center justify-center gap-2">
                 <div className={`w-16 h-16 rounded-full flex items-center justify-center text-white text-2xl font-bold shadow-md ${formData.avatarColor}`}>
                    {getIconComponent(formData.avatarIcon) || formData.name?.charAt(0) || '?'}
                 </div>
                 <span className="text-xs text-slate-500">預覽</span>
              </div>
              
              <div className="flex-1 space-y-4">
                 {/* Color Picker */}
                 <div>
                    <span className="text-xs font-bold text-slate-400 uppercase mb-2 block">選擇背景色</span>
                    <div className="flex flex-wrap gap-2">
                       {AVATAR_COLORS.map(color => (
                          <button
                            key={color}
                            type="button"
                            className={`w-8 h-8 rounded-full ${color} ${formData.avatarColor === color ? 'ring-2 ring-slate-600 ring-offset-2' : 'hover:opacity-80'}`}
                            onClick={() => setFormData({...formData, avatarColor: color})}
                          />
                       ))}
                    </div>
                 </div>

                 {/* Icon Picker */}
                 <div>
                    <span className="text-xs font-bold text-slate-400 uppercase mb-2 block">選擇圖示 (可選)</span>
                    <div className="flex flex-wrap gap-2">
                       <button
                          type="button"
                          className={`w-9 h-9 rounded-lg border flex items-center justify-center text-slate-600 font-bold bg-white transition-all ${!formData.avatarIcon ? 'border-blue-500 bg-blue-50 ring-1 ring-blue-500' : 'border-slate-200 hover:bg-slate-50'}`}
                          onClick={() => setFormData({...formData, avatarIcon: ''})}
                          title="使用姓名首字"
                       >
                          A
                       </button>
                       {USER_AVATAR_ICONS.map(icon => (
                          <button
                            key={icon}
                            type="button"
                            className={`w-9 h-9 rounded-lg border flex items-center justify-center text-slate-600 bg-white transition-all ${formData.avatarIcon === icon ? 'border-blue-500 bg-blue-50 ring-1 ring-blue-500 text-blue-600' : 'border-slate-200 hover:bg-slate-50'}`}
                            onClick={() => setFormData({...formData, avatarIcon: icon})}
                          >
                             {getIconComponent(icon)}
                          </button>
                       ))}
                    </div>
                 </div>
              </div>
           </div>
        </div>

        {(isAdmin || isSelf) && formData.role === 'ADMIN' && (
          <div className="bg-slate-50 p-3 rounded-lg border border-slate-200">
            <label className="block text-sm font-medium text-slate-700 mb-1 flex items-center gap-1">
              <Settings className="w-3 h-3" /> 登入密碼 {isAdmin && !isSelf && '(管理員修改)'}
            </label>
            <input 
              type="text" 
              className="w-full p-2 border rounded-lg font-mono text-sm" 
              placeholder="未設定 (預設無密碼)"
              value={formData.password || ''} 
              onChange={e => setFormData({...formData, password: e.target.value})} 
            />
            {isAdmin && <p className="text-xs text-slate-500 mt-1">若啟用「主管登入需密碼」，此為必填。</p>}
          </div>
        )}

        <div className="flex justify-end gap-2 pt-4">
          <Button variant="secondary" onClick={onClose}>取消</Button>
          <Button type="submit">儲存變更</Button>
        </div>
      </form>
    </Modal>
  );
};

export const QuickDispatchModal = ({ 
  isOpen, 
  onClose, 
  onSubmit, 
  users, 
  tasks, 
  categories 
}: any) => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [partNumber, setPartNumber] = useState(''); // Added Part Number state
  const [categoryId, setCategoryId] = useState(categories[0]?.id || '');
  const [estimatedHours, setEstimatedHours] = useState(categories[0]?.suggestedHours || 4);
  const [deadline, setDeadline] = useState(
    new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
  );
  const [priority, setPriority] = useState<TaskPriority>('MEDIUM');

  // Reset form when opening
  useEffect(() => {
    if (isOpen) {
       setTitle('');
       setDescription('');
       setPartNumber(''); // Reset Part Number
       if (categories.length > 0) {
          setCategoryId(categories[0].id);
          setEstimatedHours(categories[0].suggestedHours);
       }
       setDeadline(new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]);
       setPriority('MEDIUM');
    }
  }, [isOpen, categories]);

  const handleCategoryChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
     const cid = e.target.value;
     setCategoryId(cid);
     const cat = categories.find((c:Category) => c.id === cid);
     if (cat) setEstimatedHours(cat.suggestedHours);
  }

  const handleAssign = (userId: string) => {
     if (!title.trim()) {
        alert('請輸入任務標題');
        return;
     }
     
     const taskData = {
        title,
        categoryId,
        estimatedHours,
        deadline,
        priority,
        userId,
        phase: 'P2', // Default phase
        status: 'TODO',
        receiveDate: new Date().toISOString().split('T')[0],
        description: description || '快速派工建立',
        partNumber: partNumber || '', // Added Part Number
        logs: [],
        actualHours: 0
     };
     onSubmit(taskData);
     onClose();
  };

  const engineers = users.filter((u: User) => u.role === 'ENGINEER' || u.role === 'ASSISTANT');

  const getWorkloadStats = (userId: string) => {
     const userTasks = tasks.filter((t: Task) => t.userId === userId && t.status !== 'DONE');
     const count = userTasks.length;
     const hours = userTasks.reduce((acc:number, t:Task) => acc + Math.max(0, t.estimatedHours - t.actualHours), 0);
     return { count, hours };
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="⚡ 單鍵快速派工 (Quick Dispatch)" maxWidth="max-w-4xl">
       <div className="flex flex-col md:flex-row gap-6">
          {/* Task Details Form */}
          <div className="w-full md:w-1/3 space-y-4 border-r border-slate-100 pr-0 md:pr-4">
             <div>
                <label className="block text-sm font-bold text-slate-700 mb-1">任務標題</label>
                <input autoFocus type="text" className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-blue-500" placeholder="輸入工作項目..." value={title} onChange={e => setTitle(e.target.value)} />
             </div>
             <div>
                <label className="block text-sm font-bold text-slate-700 mb-1">專案品號</label>
                <input type="text" className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-blue-500 font-mono" placeholder="e.g. 805-0023-01" value={partNumber} onChange={e => setPartNumber(e.target.value)} />
             </div>
             <div>
                <label className="block text-sm font-bold text-slate-700 mb-1">任務描述 (Optional)</label>
                <textarea 
                   className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-blue-500 h-24 text-sm" 
                   placeholder="補充詳細說明..." 
                   value={description} 
                   onChange={e => setDescription(e.target.value)} 
                />
             </div>
             <div>
                <label className="block text-sm font-bold text-slate-700 mb-1">任務類別</label>
                <select className="w-full p-2 border rounded-lg" value={categoryId} onChange={handleCategoryChange}>
                   {categories.map((c: Category) => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
             </div>
             <div className="grid grid-cols-2 gap-2">
                <div>
                   <label className="block text-sm font-bold text-slate-700 mb-1">預估工時</label>
                   <input type="number" className="w-full p-2 border rounded-lg" value={estimatedHours} onChange={e => setEstimatedHours(Number(e.target.value))} />
                </div>
                <div>
                   <label className="block text-sm font-bold text-slate-700 mb-1">優先級</label>
                   <select className="w-full p-2 border rounded-lg" value={priority} onChange={e => setPriority(e.target.value as any)}>
                      <option value="HIGH">High</option>
                      <option value="MEDIUM">Medium</option>
                      <option value="LOW">Low</option>
                   </select>
                </div>
             </div>
             <div>
                <label className="block text-sm font-bold text-slate-700 mb-1">截止期限</label>
                <input type="date" className="w-full p-2 border rounded-lg" value={deadline} onChange={e => setDeadline(e.target.value)} />
             </div>
             
             <div className="bg-blue-50 p-3 rounded-lg text-xs text-blue-700 leading-relaxed">
                <Info className="w-4 h-4 inline-block mr-1 mb-0.5" />
                設定任務資訊後，直接點擊右側人員卡片上的「立即派送」按鈕即可完成分派。
             </div>
          </div>

          {/* Engineer List */}
          <div className="flex-1">
             <h3 className="text-sm font-bold text-slate-500 uppercase mb-3 flex items-center gap-2">
                人員能量即時看板 (Live Capacity)
             </h3>
             <div className="grid grid-cols-1 md:grid-cols-2 gap-3 max-h-[60vh] overflow-y-auto pr-2">
                {engineers.map((user: User) => {
                   const stats = getWorkloadStats(user.id);
                   
                   // Capacity Logic
                   let status = 'Free';
                   let color = 'bg-emerald-500';
                   let bgColor = 'bg-white hover:border-emerald-300';
                   let textColor = 'text-emerald-600';
                   
                   if (stats.count > 8) {
                      status = 'Overloaded';
                      color = 'bg-red-500';
                      bgColor = 'bg-red-50 hover:border-red-300';
                      textColor = 'text-red-600';
                   } else if (stats.count > 4) {
                      status = 'Busy';
                      color = 'bg-amber-400';
                      bgColor = 'bg-amber-50 hover:border-amber-300';
                      textColor = 'text-amber-600';
                   }

                   return (
                      <div key={user.id} className={`p-3 rounded-xl border border-slate-200 transition-all ${bgColor} group relative`}>
                         <div className="flex items-center gap-3 mb-3">
                            <UserAvatar user={user} size="md" />
                            <div>
                               <div className="font-bold text-slate-900">{user.name}</div>
                               <div className={`text-xs font-bold ${textColor}`}>{status} ({stats.count} tasks)</div>
                            </div>
                         </div>
                         
                         <div className="space-y-1 mb-3">
                            <div className="flex justify-between text-xs text-slate-400">
                               <span>待辦時數</span>
                               <span>{stats.hours}h</span>
                            </div>
                            <div className="w-full h-2 bg-slate-200 rounded-full overflow-hidden">
                               <div className={`h-full rounded-full ${color} transition-all duration-500`} style={{ width: `${Math.min(100, (stats.count / 10) * 100)}%` }}></div>
                            </div>
                         </div>
                         
                         <Button 
                           onClick={() => handleAssign(user.id)}
                           className="w-full justify-center bg-white border border-slate-200 text-slate-700 hover:bg-blue-600 hover:text-white hover:border-blue-600 transition-colors shadow-sm"
                         >
                            <Zap className="w-4 h-4 mr-1" /> 立即派送
                         </Button>
                      </div>
                   );
                })}
             </div>
          </div>
       </div>
    </Modal>
  );
};

export const StatisticsModal = ({ 
  isOpen, 
  onClose, 
  initialType = 'SCHEDULE', 
  tasks, 
  users, 
  categories 
}: {
  isOpen: boolean;
  onClose: () => void;
  initialType?: 'SCHEDULE' | 'DESIGN' | 'CHANGE';
  tasks: Task[];
  users: User[];
  categories: Category[];
}) => {
  const [activeTab, setActiveTab] = useState<'SCHEDULE' | 'DESIGN' | 'CHANGE'>(initialType);
  const [timeRange, setTimeRange] = useState<'MONTH' | 'QUARTER' | 'YEAR'>('MONTH');

  useEffect(() => {
    if (isOpen) setActiveTab(initialType);
  }, [isOpen, initialType]);

  const getDateRange = () => {
    const now = new Date();
    const start = new Date(now);
    const end = new Date(now);

    if (timeRange === 'MONTH') {
      start.setDate(1);
      start.setHours(0,0,0,0);
      end.setMonth(start.getMonth() + 1);
      end.setDate(0);
      end.setHours(23,59,59,999);
    } else if (timeRange === 'QUARTER') {
      const q = Math.floor(now.getMonth() / 3);
      start.setMonth(q * 3, 1);
      start.setHours(0,0,0,0);
      end.setMonth(start.getMonth() + 3, 0);
      end.setHours(23,59,59,999);
    } else {
      start.setMonth(0, 1);
      start.setHours(0,0,0,0);
      end.setMonth(11, 31);
      end.setHours(23,59,59,999);
    }
    return { start, end };
  };

  const { start, end } = getDateRange();

  // Helper to check date range overlap
  const isTaskInRange = (t: Task) => {
    // Primarily check Deadline for Achievement
    const d = parseDateLocal(t.deadline);
    // Or Completed Date if done
    const c = t.completedDate ? parseDateLocal(t.completedDate) : null;
    
    // Logic: If completed, use completed date. If not, use deadline.
    const refDate = c || d;
    return refDate >= start && refDate <= end;
  };

  const rangeLabel = timeRange === 'MONTH' ? '本月' : timeRange === 'QUARTER' ? '本季' : '本年度';

  // --- Statistics Logic ---
  
  // 1. Schedule Achievement
  const scheduleStats = useMemo(() => {
    const relevantTasks = tasks.filter(t => isTaskInRange(t));
    const total = relevantTasks.length;
    let onTime = 0;
    
    // Breakdown by Category
    const catStats: Record<string, { total: number, onTime: number }> = {};
    
    relevantTasks.forEach(t => {
      const isDone = t.status === 'DONE';
      const deadline = parseDateLocal(t.deadline);
      const completed = t.completedDate ? parseDateLocal(t.completedDate) : null;
      
      let success = false;
      if (isDone && completed && completed <= deadline) success = true;
      
      if (success) onTime++;

      // Category Grouping
      const cId = t.categoryId;
      if (!catStats[cId]) catStats[cId] = { total: 0, onTime: 0 };
      catStats[cId].total++;
      if (success) catStats[cId].onTime++;
    });

    return { total, onTime, rate: total > 0 ? Math.round((onTime/total)*100) : 0, catStats };
  }, [tasks, timeRange, start, end]);

  // 2. Design Success (DV)
  const designStats = useMemo(() => {
    // Filter tasks that are related to Verification/Testing and have DV counts
    const relevantTasks = tasks.filter(t => {
       // Must be in range
       if (!isTaskInRange(t)) return false;
       // Must have DV data
       return (t.dvCount || 0) > 0;
    });

    const totalItems = relevantTasks.reduce((acc, t) => acc + (t.dvCount || 0), 0);
    const passedItems = relevantTasks.reduce((acc, t) => acc + (t.dvAchieved || 0), 0);
    
    return { totalItems, passedItems, rate: totalItems > 0 ? Math.round((passedItems/totalItems)*100) : 0, taskCount: relevantTasks.length };
  }, [tasks, timeRange, start, end]);

  // 3. Change Stats
  const changeStats = useMemo(() => {
    const relevantTasks = tasks.filter(t => {
       if (!isTaskInRange(t)) return false;
       // Must contain change info
       return (t.changeCount || 0) > 0 || !!(t.changeOrderNumber);
    });

    const totalChanges = relevantTasks.reduce((acc, t) => acc + (t.changeCount ?? 0), 0);
    
    // Group by Change Category (Reason)
    const reasonStats: Record<string, number> = {};
    relevantTasks.forEach(t => {
       const r = t.changeCategory || '未分類';
       const currentCount = reasonStats[r] ?? 0;
       const addCount = t.changeCount ?? 1;
       reasonStats[r] = currentCount + addCount;
    });

    return { totalChanges, reasonStats, taskCount: relevantTasks.length };
  }, [tasks, timeRange, start, end]);

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="圖形化統計監控中心 (Visual Analytics)" maxWidth="max-w-5xl">
       {/* Header Controls */}
       <div className="flex flex-col md:flex-row justify-between items-center mb-6 gap-4">
          <div className="flex bg-slate-100 p-1 rounded-lg">
             {(['SCHEDULE', 'DESIGN', 'CHANGE'] as const).map(type => (
               <button
                 key={type}
                 onClick={() => setActiveTab(type)}
                 className={`px-4 py-2 rounded-md text-sm font-bold transition-all flex items-center gap-2 ${activeTab === type ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
               >
                 {type === 'SCHEDULE' && <Calendar className="w-4 h-4" />}
                 {type === 'DESIGN' && <Target className="w-4 h-4" />}
                 {type === 'CHANGE' && <RotateCcw className="w-4 h-4" />}
                 {type === 'SCHEDULE' && '日程達成率'}
                 {type === 'DESIGN' && '設計成功率'}
                 {type === 'CHANGE' && '變更統計'}
               </button>
             ))}
          </div>

          <div className="flex items-center gap-2">
             <span className="text-xs font-bold text-slate-400 uppercase">時間維度:</span>
             <div className="flex bg-slate-100 p-1 rounded-lg">
                {(['MONTH', 'QUARTER', 'YEAR'] as const).map(range => (
                  <button
                    key={range}
                    onClick={() => setTimeRange(range)}
                    className={`px-3 py-1 rounded-md text-xs font-bold transition-all ${timeRange === range ? 'bg-slate-700 text-white shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
                  >
                    {range === 'MONTH' ? '月' : range === 'QUARTER' ? '季' : '年'}
                  </button>
                ))}
             </div>
          </div>
       </div>

       {/* Content Area */}
       <div className="min-h-[400px]">
          {/* 1. Schedule View */}
          {activeTab === 'SCHEDULE' && (
             <div className="animate-in fade-in slide-in-from-bottom-4 duration-500 space-y-6">
                <div className="flex flex-col md:flex-row gap-6">
                   {/* Big Number Card */}
                   <div className="w-full md:w-1/3 bg-blue-50 rounded-2xl p-6 border border-blue-100 flex flex-col items-center justify-center text-center">
                      <div className="text-sm font-bold text-blue-500 uppercase tracking-wide mb-2">{rangeLabel}達成率</div>
                      <div className="text-6xl font-black text-blue-600 mb-2">{scheduleStats.rate}<span className="text-2xl">%</span></div>
                      <div className="text-sm text-blue-400 font-medium">準時: {scheduleStats.onTime} / 總數: {scheduleStats.total}</div>
                      {/* Visual Bar */}
                      <div className="w-full h-3 bg-blue-200 rounded-full mt-4 overflow-hidden">
                         <div className="h-full bg-blue-500 rounded-full transition-all duration-1000" style={{ width: `${scheduleStats.rate}%` }}></div>
                      </div>
                   </div>

                   {/* Category Breakdown Bar Chart */}
                   <div className="flex-1 bg-white border border-slate-200 rounded-2xl p-6">
                      <h3 className="font-bold text-slate-800 mb-4 flex items-center gap-2">
                         <BarChart3 className="w-5 h-5 text-slate-500" /> 各類別達成狀況
                      </h3>
                      <div className="space-y-4">
                         {categories.map(cat => {
                            const stat = scheduleStats.catStats[cat.id] || { total: 0, onTime: 0 };
                            if (stat.total === 0) return null;
                            const rate = Math.round((stat.onTime / stat.total) * 100);
                            let color = 'bg-emerald-500';
                            if (rate < 60) color = 'bg-red-500';
                            else if (rate < 80) color = 'bg-amber-400';

                            return (
                               <div key={cat.id}>
                                  <div className="flex justify-between text-sm mb-1">
                                     <span className="font-bold text-slate-700 flex items-center gap-2">
                                        {getCategoryIconComponent(cat.icon)} {cat.name}
                                     </span>
                                     <span className="text-slate-500">{rate}% ({stat.onTime}/{stat.total})</span>
                                  </div>
                                  <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                                     <div className={`h-full rounded-full ${color} transition-all duration-1000`} style={{ width: `${rate}%` }}></div>
                                  </div>
                               </div>
                            );
                         })}
                         {Object.keys(scheduleStats.catStats).length === 0 && (
                            <div className="text-center text-slate-400 py-8">無相關數據</div>
                         )}
                      </div>
                   </div>
                </div>
             </div>
          )}

          {/* 2. Design Success View */}
          {activeTab === 'DESIGN' && (
             <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                   {/* Radial Chart Area */}
                   <div className="bg-indigo-50 rounded-2xl p-6 border border-indigo-100 flex flex-col items-center justify-center relative min-h-[300px]">
                      <h3 className="absolute top-6 left-6 font-bold text-indigo-800 flex items-center gap-2">
                         <Microscope className="w-5 h-5" /> DV 驗證通過率
                      </h3>
                      
                      {/* SVG Circle Chart */}
                      <div className="relative w-48 h-48">
                         <svg className="w-full h-full transform -rotate-90" viewBox="0 0 192 192">
                            <circle cx="96" cy="96" r="88" stroke="currentColor" strokeWidth="12" fill="transparent" className="text-indigo-200" />
                            <circle 
                              cx="96" cy="96" r="88" 
                              stroke="currentColor" strokeWidth="12" 
                              fill="transparent" 
                              className="text-indigo-600 transition-all duration-1000 ease-out"
                              strokeDasharray={2 * Math.PI * 88}
                              strokeDashoffset={2 * Math.PI * 88 * (1 - designStats.rate / 100)}
                              strokeLinecap={designStats.rate > 0 ? "round" : "butt"}
                            />
                         </svg>
                         <div className="absolute inset-0 flex flex-col items-center justify-center">
                            <span className="text-4xl font-black text-indigo-700">{designStats.rate}%</span>
                            <span className="text-xs text-indigo-400 font-bold uppercase">{rangeLabel}累積</span>
                         </div>
                      </div>
                   </div>

                   {/* Stats Details */}
                   <div className="bg-white border border-slate-200 rounded-2xl p-6 flex flex-col justify-center space-y-6">
                      <div className="flex items-center gap-4">
                         <div className="p-3 bg-indigo-100 text-indigo-600 rounded-xl">
                            <Target className="w-6 h-6" />
                         </div>
                         <div>
                            <div className="text-sm text-slate-500">總驗證項目 (Total Items)</div>
                            <div className="text-2xl font-bold text-slate-800">{designStats.totalItems} <span className="text-sm font-normal text-slate-400">項</span></div>
                         </div>
                      </div>

                      <div className="flex items-center gap-4">
                         <div className="p-3 bg-emerald-100 text-emerald-600 rounded-xl">
                            <CheckCircle2 className="w-6 h-6" />
                         </div>
                         <div>
                            <div className="text-sm text-slate-500">已通過項目 (Passed)</div>
                            <div className="text-2xl font-bold text-slate-800">{designStats.passedItems} <span className="text-sm font-normal text-slate-400">項</span></div>
                         </div>
                      </div>

                      <div className="flex items-center gap-4">
                         <div className="p-3 bg-slate-100 text-slate-600 rounded-xl">
                            <Briefcase className="w-6 h-6" />
                         </div>
                         <div>
                            <div className="text-sm text-slate-500">相關任務數 (Tasks)</div>
                            <div className="text-2xl font-bold text-slate-800">{designStats.taskCount} <span className="text-sm font-normal text-slate-400">筆</span></div>
                         </div>
                      </div>
                   </div>
                </div>
             </div>
          )}

          {/* 3. Change Stats View */}
          {activeTab === 'CHANGE' && (
             <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
                <div className="flex flex-col gap-6">
                   {/* Summary Row */}
                   <div className="flex gap-4">
                      <div className="flex-1 bg-orange-50 p-6 rounded-2xl border border-orange-100 flex items-center justify-between">
                         <div>
                            <div className="text-orange-800 font-bold text-lg mb-1">設計變更總次數</div>
                            <div className="text-orange-600/70 text-sm">統計區間: {rangeLabel}</div>
                         </div>
                         <div className="text-5xl font-black text-orange-600">{changeStats.totalChanges}</div>
                      </div>
                      <div className="w-48 bg-white border border-slate-200 p-6 rounded-2xl flex flex-col justify-center items-center">
                          <div className="text-slate-400 text-xs font-bold uppercase mb-1">影響任務</div>
                          <div className="text-3xl font-bold text-slate-800">{changeStats.taskCount}</div>
                      </div>
                   </div>

                   {/* Bar Chart for Change Reasons */}
                   <div className="bg-white border border-slate-200 rounded-2xl p-6 min-h-[300px]">
                      <h3 className="font-bold text-slate-800 mb-6 flex items-center gap-2">
                         <Activity className="w-5 h-5 text-orange-500" /> 變更原因分析 (Change Analysis)
                      </h3>
                      
                      {Object.keys(changeStats.reasonStats).length > 0 ? (
                         <div className="space-y-4">
                            {Object.entries(changeStats.reasonStats)
                               .sort(([,a], [,b]) => (b as number) - (a as number))
                               .map(([reason, count]) => {
                                  const percentage = Math.round(((count as number) / changeStats.totalChanges) * 100);
                                  return (
                                     <div key={reason} className="relative">
                                        <div className="flex justify-between text-sm mb-1 z-10 relative">
                                           <span className="font-bold text-slate-700">{reason}</span>
                                           <span className="text-slate-500">{count}次 ({percentage}%)</span>
                                        </div>
                                        <div className="w-full h-8 bg-slate-50 rounded-lg overflow-hidden relative border border-slate-100">
                                            <div 
                                              className="h-full bg-gradient-to-r from-orange-400 to-red-400 opacity-80 rounded-lg transition-all duration-1000" 
                                              style={{ width: `${percentage}%` }}
                                            ></div>
                                        </div>
                                     </div>
                                  );
                               })}
                         </div>
                      ) : (
                         <div className="h-48 flex items-center justify-center text-slate-400">
                            無變更紀錄
                         </div>
                      )}
                   </div>
                </div>
             </div>
          )}
       </div>
    </Modal>
  );
};

export const TransferModal = ({ isOpen, onClose, onConfirm, users, taskTitle }: { isOpen: boolean; onClose: () => void; onConfirm: (uid: string) => void; users: User[]; taskTitle: string }) => {
  const [selectedUser, setSelectedUser] = useState(users[0]?.id || '');

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="轉派任務" zIndex="z-[60]">
      <div className="space-y-4">
        <p className="text-slate-600">您正在轉派任務：<span className="font-bold text-slate-900">{taskTitle}</span></p>
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">選擇接手人員</label>
          <select className="w-full p-2 border rounded-lg" value={selectedUser} onChange={e => setSelectedUser(e.target.value)}>
            {users.map(u => <option key={u.id} value={u.id}>{u.name} ({u.employeeId})</option>)}
          </select>
        </div>
        <div className="flex justify-end gap-2 pt-4">
          <Button variant="secondary" onClick={onClose}>取消</Button>
          <Button onClick={() => { onConfirm(selectedUser); onClose(); }}>確認轉派</Button>
        </div>
      </div>
    </Modal>
  );
};

export const UserDetailModal = ({ isOpen, onClose, user, tasks, onTransferTask, categories }: { isOpen: boolean; onClose: () => void; user: User | null; tasks: Task[]; onTransferTask?: (t: Task) => void; categories: Category[] }) => {
  if (!user) return null;
  const userTasks = tasks.filter(t => t.userId === user.id);
  const activeTasks = userTasks.filter(t => t.status !== 'DONE');
  const completedTasks = userTasks.filter(t => t.status === 'DONE');

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="成員詳情" maxWidth="max-w-2xl">
      <div className="flex items-center gap-4 mb-6">
        <UserAvatar user={user} size="xl" showShadow />
        <div>
          <h2 className="text-xl font-bold text-slate-900">{user.name}</h2>
          <p className="text-slate-500">{user.employeeId} • {user.role}</p>
        </div>
      </div>
      
      <h3 className="font-bold text-slate-800 mb-2">進行中任務 ({activeTasks.length})</h3>
      <div className="space-y-2 mb-6 max-h-80 overflow-y-auto">
        {activeTasks.length > 0 ? activeTasks.map(task => (
           <TaskItem 
             key={task.id} 
             task={task} 
             categories={categories} 
             showLogsToggle={true} 
             onTransfer={onTransferTask ? () => onTransferTask(task) : undefined} 
           />
        )) : <p className="text-slate-400 text-center text-sm">無進行中任務</p>}
      </div>

      <h3 className="font-bold text-slate-800 mb-2">已完成任務 (近5筆)</h3>
      <div className="space-y-2">
         {completedTasks.slice(0, 5).map(task => (
           <TaskItem key={task.id} task={task} categories={categories} showLogsToggle={true} />
         ))}
         {completedTasks.length === 0 && <p className="text-slate-400 text-center text-sm">尚無完成紀錄</p>}
      </div>
    </Modal>
  );
};

export const DailyWorkloadModal = ({ 
  isOpen, 
  onClose, 
  dateStr, 
  tasks, 
  categories 
}: { 
  isOpen: boolean; 
  onClose: () => void; 
  dateStr: string | null; 
  tasks: Task[]; 
  categories: Category[];
}) => {
  if (!dateStr) return null;
  
  const displayDate = parseDateLocal(dateStr).toLocaleDateString('zh-TW', { month: 'long', day: 'numeric', weekday: 'long' });

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={`工作清單 - ${displayDate}`} maxWidth="max-w-3xl">
       <div className="space-y-2 max-h-[60vh] overflow-y-auto">
         {tasks.length > 0 ? tasks.map((task: Task) => (
            <TaskItem 
              key={task.id}
              task={task} 
              categories={categories} 
              showOwner 
              showLogsToggle={true}
            />
         )) : (
            <div className="text-center py-8 text-slate-400">
              <Calendar className="w-12 h-12 mx-auto mb-2 opacity-20" />
              <p>本日無排定主要工作</p>
            </div>
         )}
       </div>
    </Modal>
  );
};

export const TeamDailyWorkloadModal = ({
  isOpen,
  onClose,
  dateStr,
  users,
  tasks
}: {
  isOpen: boolean;
  onClose: () => void;
  dateStr: string | null;
  users: User[];
  tasks: Task[];
}) => {
  if (!dateStr) return null;

  const targetDate = parseDateLocal(dateStr);
  const displayDate = targetDate.toLocaleDateString('zh-TW', { month: 'long', day: 'numeric', weekday: 'long' });
  const engineers = users.filter(u => u.role === 'ENGINEER');

  // Calculate load per engineer for this specific day
  const engineerLoads = engineers.map(eng => {
      const engTasks = tasks.filter(t => t.userId === eng.id && t.status !== 'DONE');
      let dailyLoad = 0;
      const relevantTasks: Task[] = [];

      engTasks.forEach(task => {
          const remaining = Math.max(0, task.estimatedHours - task.actualHours);
          if (remaining <= 0) return;

          let start = new Date(task.startDate ? task.startDate : new Date());
          if (start < new Date()) start = new Date();
          start.setHours(0,0,0,0);

          let end = new Date(task.deadline);
          end.setHours(0,0,0,0);
          if (end < start) end = new Date(start);

          // Check if targetDate is within range [start, end]
          if (targetDate.getTime() >= start.getTime() && targetDate.getTime() <= end.getTime()) {
              // Calculate business days
              let businessDays = 0;
              let temp = new Date(start);
              while (temp <= end) {
                  const d = temp.getDay();
                  if (d !== 0 && d !== 6) businessDays++;
                  temp.setDate(temp.getDate() + 1);
              }
              if (businessDays === 0) businessDays = 1;
              
              const load = remaining / businessDays;
              dailyLoad += load;
              relevantTasks.push(task);
          }
      });
      
      return { user: eng, load: dailyLoad, tasks: relevantTasks };
  }).sort((a,b) => b.load - a.load);

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={`團隊產能詳情 - ${displayDate}`} maxWidth="max-w-4xl">
       <div className="space-y-4 max-h-[60vh] overflow-y-auto pr-2">
          {engineerLoads.map(({ user, load, tasks }) => {
             const percentage = Math.min(100, (load / 8) * 100);
             let colorClass = "bg-emerald-500";
             let statusText = "餘裕";
             let statusColor = "text-emerald-600";
             
             if (load > 8) {
                 colorClass = "bg-red-500";
                 statusText = "超載";
                 statusColor = "text-red-600 font-bold";
             } else if (load > 6) {
                 colorClass = "bg-orange-500";
                 statusText = "滿載";
                 statusColor = "text-orange-600 font-bold";
             } else if (load > 4) {
                 colorClass = "bg-amber-400";
                 statusText = "忙碌";
                 statusColor = "text-amber-600";
             }

             return (
               <div key={user.id} className="bg-slate-50 rounded-lg p-3 border border-slate-200">
                  <div className="flex items-center gap-4 mb-2">
                      <UserAvatar user={user} size="md" />
                      <div className="w-32 shrink-0">
                         <div className="font-bold text-slate-800">{user.name}</div>
                         <div className={`text-xs ${statusColor}`}>{statusText} ({load.toFixed(1)}h)</div>
                      </div>
                      
                      <div className="flex-1">
                          <div className="w-full h-2 bg-slate-200 rounded-full overflow-hidden">
                              <div className={`h-full rounded-full ${colorClass}`} style={{ width: `${percentage}%` }}></div>
                          </div>
                      </div>
                  </div>
                  
                  {/* Task Preview Chips */}
                  <div className="flex flex-wrap gap-2 ml-14">
                      {tasks.length > 0 ? tasks.map(t => (
                          <div key={t.id} className="text-xs bg-white border border-slate-200 px-2 py-1 rounded text-slate-600 truncate max-w-[200px]" title={t.title}>
                             {t.partNumber ? `${t.partNumber} ` : ''}{t.title}
                          </div>
                      )) : (
                          <span className="text-xs text-slate-400 italic">本日無主要排程</span>
                      )}
                  </div>
               </div>
             );
          })}
       </div>
    </Modal>
  );
};

export const TaskModal = ({ isOpen, onClose, onSubmit, editingTask, categories, users, currentUser, onRequestDateChange, tasks }: any) => {
  const [formData, setFormData] = useState<Partial<Task>>({
    title: '', description: '', categoryId: categories[0]?.id || '', priority: 'MEDIUM', phase: 'P2',
    estimatedHours: 4, receiveDate: new Date().toISOString().split('T')[0], deadline: new Date().toISOString().split('T')[0],
    partNumber: '', userId: currentUser?.id,
    dvCount: 0, dvAchieved: 0,
    changeOrderNumber: '', changeCount: 1, changeCategory: CHANGE_CATEGORY_OPTIONS[0], changeAnalysis: CHANGE_ANALYSIS_OPTIONS[0]
  });
  const [changeReason, setChangeReason] = useState('');
  
  useEffect(() => {
    if (editingTask) {
      setFormData(editingTask);
    } else {
      const defaultCat = categories[0];
      setFormData({
        title: '', description: '', categoryId: defaultCat?.id || '', priority: 'MEDIUM', phase: 'P2',
        estimatedHours: defaultCat?.suggestedHours || 4, 
        receiveDate: new Date().toISOString().split('T')[0], deadline: new Date().toISOString().split('T')[0],
        partNumber: '', userId: currentUser?.id,
        dvCount: 0, dvAchieved: 0,
        changeOrderNumber: '', changeCount: 1, changeCategory: CHANGE_CATEGORY_OPTIONS[0], changeAnalysis: CHANGE_ANALYSIS_OPTIONS[0]
      });
    }
    setChangeReason('');
  }, [editingTask, isOpen, currentUser, categories]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (editingTask && currentUser.role !== 'ADMIN' && onRequestDateChange) {
       const isDateChanged = formData.receiveDate !== editingTask.receiveDate || formData.deadline !== editingTask.deadline;
       if (isDateChanged) {
         if (!changeReason.trim()) {
           alert('請填寫日期變更原因');
           return;
         }
         const request: DateChangeRequest = {
           newReceiveDate: formData.receiveDate!,
           newDeadline: formData.deadline!,
           reason: changeReason,
           requesterId: currentUser.id,
           requestedAt: new Date().toISOString()
         };
         onRequestDateChange(editingTask.id, request);
         onClose();
         return;
       }
    }
    
    onSubmit(formData);
    onClose();
  };
  
  const handleCategoryChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const newCatId = e.target.value;
    const cat = categories.find((c: Category) => c.id === newCatId);
    
    setFormData(prev => ({
        ...prev,
        categoryId: newCatId,
        estimatedHours: cat ? cat.suggestedHours : prev.estimatedHours 
    }));
  };

  const isDateChanged = editingTask && (formData.receiveDate !== editingTask.receiveDate || formData.deadline !== editingTask.deadline);
  const needsApproval = isDateChanged && currentUser.role !== 'ADMIN';

  const selectedCategory = categories.find((c: Category) => c.id === formData.categoryId);
  
  const isVerificationTask = selectedCategory?.name.includes('測試') || selectedCategory?.name.includes('驗證') || selectedCategory?.name.includes('試模') || selectedCategory?.name.includes('Test');
  
  const isDesignChangeTask = selectedCategory?.name.includes('設計變更');

  const designSuccessRate = (formData.dvCount && formData.dvCount > 0) 
    ? Math.round(((formData.dvAchieved || 0) / formData.dvCount) * 100) 
    : 0;

  // Workload Calculation Helper for Admin View
  const getUserWorkload = (uid: string) => {
      if (!tasks) return { count: 0, hours: 0 };
      const activeUserTasks = tasks.filter((t: Task) => t.userId === uid && t.status !== 'DONE');
      const count = activeUserTasks.length;
      const hours = activeUserTasks.reduce((acc: number, t: Task) => acc + Math.max(0, t.estimatedHours - t.actualHours), 0);
      
      // Calculate earliest deadline
      const sorted = activeUserTasks.sort((a: Task, b: Task) => new Date(a.deadline).getTime() - new Date(b.deadline).getTime());
      const nextDeadline = sorted.length > 0 ? sorted[0].deadline : null;

      return { count, hours, nextDeadline };
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={editingTask ? '編輯任務' : '建立任務'} maxWidth="max-w-2xl" zIndex="z-[60]">
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
           <div className="md:col-span-2">
             <label className="block text-sm font-medium text-slate-700 mb-1">任務標題</label>
             <input required type="text" className="w-full p-2 border rounded-lg" value={formData.title} onChange={e => setFormData({...formData, title: e.target.value})} />
           </div>
           
           <div className="md:col-span-2">
             <label className="block text-sm font-medium text-slate-700 mb-1">任務描述</label>
             <textarea className="w-full p-2 border rounded-lg h-24" value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})} />
           </div>

           <div>
             <label className="block text-sm font-medium text-slate-700 mb-1">專案品號 (Part Number)</label>
             <input type="text" className="w-full p-2 border rounded-lg font-mono" value={formData.partNumber || ''} onChange={e => setFormData({...formData, partNumber: e.target.value})} placeholder="e.g. 805-0023-01" />
           </div>

           <div>
             <label className="block text-sm font-medium text-slate-700 mb-1">任務類別</label>
             <select 
                className="w-full p-2 border rounded-lg" 
                value={formData.categoryId} 
                onChange={handleCategoryChange}
             >
               {categories.map((c: Category) => <option key={c.id} value={c.id}>{c.name}</option>)}
             </select>
           </div>
           
           {isDesignChangeTask && (
             <div className="md:col-span-2 bg-orange-50 p-4 rounded-lg border border-orange-200 grid grid-cols-1 md:grid-cols-2 gap-4 animate-in fade-in duration-300">
                <div className="md:col-span-2 text-sm font-bold text-orange-700 flex items-center gap-2">
                   <RotateCcw className="w-4 h-4" /> 設計變更資訊
                </div>
                
                <div>
                   <label className="block text-xs font-bold text-orange-800 mb-1">變更單號</label>
                   <input 
                      type="text" 
                      className="w-full p-2 border border-orange-300 rounded-lg text-sm"
                      placeholder="例如: ECN-2023001"
                      value={formData.changeOrderNumber || ''}
                      onChange={e => setFormData({...formData, changeOrderNumber: e.target.value})}
                   />
                </div>
                <div>
                   <label className="block text-xs font-bold text-orange-800 mb-1">變更次數</label>
                   <input 
                      type="number" 
                      min="1"
                      className="w-full p-2 border border-orange-300 rounded-lg text-sm"
                      value={formData.changeCount || 1}
                      onChange={e => setFormData({...formData, changeCount: Number(e.target.value)})}
                   />
                </div>
                
                <div>
                   <label className="block text-xs font-bold text-orange-800 mb-1">變更分類</label>
                   <select 
                      className="w-full p-2 border border-orange-300 rounded-lg text-sm"
                      value={formData.changeCategory || CHANGE_CATEGORY_OPTIONS[0]}
                      onChange={e => setFormData({...formData, changeCategory: e.target.value})}
                   >
                      {CHANGE_CATEGORY_OPTIONS.map(opt => (
                         <option key={opt} value={opt}>{opt}</option>
                      ))}
                   </select>
                </div>

                <div>
                   <label className="block text-xs font-bold text-orange-800 mb-1">變更分析</label>
                   <select 
                      className="w-full p-2 border border-orange-300 rounded-lg text-sm"
                      value={formData.changeAnalysis || CHANGE_ANALYSIS_OPTIONS[0]}
                      onChange={e => setFormData({...formData, changeAnalysis: e.target.value})}
                   >
                      {CHANGE_ANALYSIS_OPTIONS.map(opt => (
                         <option key={opt} value={opt}>{opt}</option>
                      ))}
                   </select>
                </div>
             </div>
           )}
           
           {selectedCategory?.note && (
             <div className="md:col-span-2 animate-in fade-in duration-300">
               <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 flex items-start gap-3">
                 <Info className="w-5 h-5 text-amber-500 mt-0.5 shrink-0" />
                 <div>
                   <h4 className="text-sm font-bold text-amber-700">類別注意事項 (Precautions)</h4>
                   <p className="text-sm text-amber-800 leading-relaxed mt-1">
                     {selectedCategory.note}
                   </p>
                 </div>
               </div>
             </div>
           )}

           <div>
             <label className="block text-sm font-medium text-slate-700 mb-1">專案階段</label>
             <select className="w-full p-2 border rounded-lg" value={formData.phase} onChange={e => setFormData({...formData, phase: e.target.value as ProjectPhase})}>
               <option value="P1">P1 (提案/估價)</option>
               <option value="P2">P2 (設計凍結)</option>
               <option value="P3">P3 (驗證DV/PV)</option>
               <option value="P4">P4 (結案)</option>
               <option value="P5">P5 (工程變更)</option>
             </select>
           </div>

           <div>
             <label className="block text-sm font-medium text-slate-700 mb-1">優先級</label>
             <select className="w-full p-2 border rounded-lg" value={formData.priority} onChange={e => setFormData({...formData, priority: e.target.value as TaskPriority})}>
               <option value="HIGH">High (緊急)</option>
               <option value="MEDIUM">Medium (一般)</option>
               <option value="LOW">Low (低)</option>
             </select>
           </div>
           
           <div>
             <label className="block text-sm font-medium text-slate-700 mb-1">接收日期</label>
             <input required type="date" className="w-full p-2 border rounded-lg" value={formData.receiveDate} onChange={e => setFormData({...formData, receiveDate: e.target.value})} />
           </div>

           <div>
             <label className="block text-sm font-medium text-slate-700 mb-1">預計完成日 (Deadline)</label>
             <input required type="date" className="w-full p-2 border rounded-lg" value={formData.deadline} onChange={e => setFormData({...formData, deadline: e.target.value})} />
           </div>
           
           <div>
             <label className="block text-sm font-medium text-slate-700 mb-1">預估工時 (小時)</label>
             <input required type="number" min="0.5" step="0.5" className="w-full p-2 border rounded-lg" value={formData.estimatedHours} onChange={e => setFormData({...formData, estimatedHours: Number(e.target.value)})} />
           </div>
           
           {currentUser.role === 'ADMIN' && users && (
             <div className="md:col-span-2 bg-slate-50 p-3 rounded-lg border border-slate-200">
               <label className="block text-sm font-bold text-slate-700 mb-2 flex items-center gap-2">
                  <UserIcon className="w-4 h-4 text-blue-500" /> 指派人員 (Workload Check)
               </label>
               <select 
                 className="w-full p-2 border rounded-lg mb-2" 
                 value={formData.userId} 
                 onChange={e => setFormData({...formData, userId: e.target.value})}
               >
                 {users.map((u: User) => {
                    const stats = getUserWorkload(u.id);
                    return (
                        <option key={u.id} value={u.id}>
                           {u.name} (進行中: {stats.count})
                        </option>
                    );
                 })}
               </select>

               {/* Selected User Workload Visual */}
               {formData.userId && (
                 (() => {
                    const selectedUser = users.find((u:User) => u.id === formData.userId);
                    const stats = getUserWorkload(formData.userId);
                    
                    let loadColor = "bg-emerald-500";
                    let loadText = "餘裕 (Low Load)";
                    let textColor = "text-emerald-700";
                    let bgColor = "bg-emerald-50 border-emerald-200";

                    if (stats.count > 6) {
                        loadColor = "bg-red-500";
                        loadText = "繁忙 (Heavy Load)";
                        textColor = "text-red-700";
                        bgColor = "bg-red-50 border-red-200";
                    } else if (stats.count > 3) {
                        loadColor = "bg-amber-400";
                        loadText = "適中 (Medium Load)";
                        textColor = "text-amber-700";
                        bgColor = "bg-amber-50 border-amber-200";
                    }

                    return (
                      <div className={`mt-2 p-3 rounded-lg border ${bgColor} flex items-center gap-4 animate-in fade-in`}>
                         <div className="shrink-0">
                            <UserAvatar user={selectedUser} size="md" />
                         </div>
                         <div className="flex-1">
                            <div className="flex justify-between items-center mb-1">
                               <span className={`text-sm font-bold ${textColor}`}>{loadText}</span>
                               <span className="text-xs text-slate-500 font-medium">累積待辦: {stats.hours}h</span>
                            </div>
                            <div className="w-full h-2 bg-white rounded-full overflow-hidden border border-slate-200">
                               <div 
                                 className={`h-full rounded-full ${loadColor} transition-all duration-500`} 
                                 style={{ width: `${Math.min(100, (stats.count / 10) * 100)}%` }}
                               ></div>
                            </div>
                            <div className="flex justify-between mt-1">
                               <span className="text-xs text-slate-500">進行中任務: {stats.count}</span>
                               {stats.nextDeadline && <span className="text-xs text-slate-500">最近截止: {stats.nextDeadline}</span>}
                            </div>
                         </div>
                      </div>
                    );
                 })()
               )}
             </div>
           )}

           {isVerificationTask && editingTask && (
             <div className="md:col-span-2 bg-indigo-50 p-4 rounded-lg border border-indigo-200 mt-2">
                <h4 className="font-bold text-indigo-800 mb-3 flex items-center gap-2">
                   <Microscope className="w-4 h-4"/> 試模/驗證結果回報 (Result Reporting)
                </h4>
                <div className="grid grid-cols-2 gap-4">
                    <div>
                       <label className="block text-sm font-medium text-indigo-900 mb-1">DV 項目總數 (Total Items)</label>
                       <input 
                          type="number" 
                          min="0"
                          className="w-full p-2 border border-indigo-300 rounded-lg text-center font-bold text-indigo-700"
                          value={formData.dvCount || 0}
                          onChange={e => setFormData({...formData, dvCount: Number(e.target.value)})}
                       />
                    </div>
                    <div>
                       <label className="block text-sm font-medium text-indigo-900 mb-1">DV 達成項目數 (Achieved)</label>
                       <input 
                          type="number" 
                          min="0"
                          className="w-full p-2 border border-indigo-300 rounded-lg text-center font-bold text-indigo-700"
                          value={formData.dvAchieved || 0}
                          onChange={e => setFormData({...formData, dvAchieved: Number(e.target.value)})}
                       />
                    </div>
                </div>
                <div className="flex justify-end items-center mt-2 gap-2">
                   <span className="text-sm text-indigo-600">自動計算設計成功率:</span>
                   <span className="text-xl font-bold text-indigo-700">{designSuccessRate}%</span>
                </div>
             </div>
           )}
        </div>
        
        {needsApproval && (
          <div className="bg-orange-50 p-4 rounded-lg border border-orange-200 animate-in fade-in">
             <div className="flex items-center gap-2 text-orange-700 font-bold mb-2">
                <AlertTriangle className="w-4 h-4" /> 需要簽核
             </div>
             <p className="text-xs text-orange-600 mb-2">您修改了任務日期，這需要主管簽核才能生效。</p>
             <label className="block text-sm font-medium text-slate-700 mb-1">變更原因 *</label>
             <input required type="text" className="w-full p-2 border border-orange-300 rounded-lg bg-white" placeholder="請輸入延期/變更原因..." value={changeReason} onChange={e => setChangeReason(e.target.value)} />
          </div>
        )}

        <div className="flex justify-end gap-2 pt-4">
          <Button variant="secondary" onClick={onClose}>取消</Button>
          <Button type="submit">{needsApproval ? '送出變更申請' : '儲存任務'}</Button>
        </div>
      </form>
    </Modal>
  );
};

export const LogModal = ({ isOpen, onClose, onSubmit, taskTitle }: { isOpen: boolean; onClose: () => void; onSubmit: (data: any) => void; taskTitle: string }) => {
  const [content, setContent] = useState('');
  const [hoursSpent, setHoursSpent] = useState(1);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({ content, hoursSpent });
    setContent('');
    setHoursSpent(1);
    onClose();
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="填寫工作日誌" zIndex="z-[60]">
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="bg-slate-50 p-3 rounded text-sm text-slate-600 mb-2">
          任務：<span className="font-bold">{taskTitle}</span>
        </div>
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">工作內容說明</label>
          <textarea required className="w-full p-2 border rounded-lg h-32" placeholder="請簡述今日進度..." value={content} onChange={e => setContent(e.target.value)} />
        </div>
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">投入工時 (小時)</label>
          <input required type="number" min="0.5" step="0.5" className="w-full p-2 border rounded-lg" value={hoursSpent} onChange={e => setHoursSpent(Number(e.target.value))} />
        </div>
        <div className="flex justify-end gap-2 pt-4">
          <Button variant="secondary" onClick={onClose}>取消</Button>
          <Button type="submit">新增日誌</Button>
        </div>
      </form>
    </Modal>
  );
};

export const CategoryModal = ({ isOpen, onClose, categories, onAddCategory, onUpdateCategory, onDeleteCategory, onReorderCategories }: any) => {
  const [newCatName, setNewCatName] = useState('');
  const [newCatHours, setNewCatHours] = useState(1);
  const [newCatNote, setNewCatNote] = useState('');
  const [newCatIcon, setNewCatIcon] = useState('layers');

  // Editing state
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editFormData, setEditFormData] = useState<Partial<Category>>({});
  
  // Icon Picker toggle for editing row (mobile friendly)
  const [showIconMenu, setShowIconMenu] = useState(false);

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (newCatName) {
      onAddCategory(newCatName, newCatHours, newCatNote, newCatIcon);
      setNewCatName('');
      setNewCatNote('');
      setNewCatIcon('layers');
    }
  };

  const startEdit = (cat: Category) => {
    setEditingId(cat.id);
    setShowIconMenu(false); 
    setEditFormData({
      name: cat.name,
      suggestedHours: cat.suggestedHours,
      note: cat.note || '',
      icon: cat.icon || 'layers'
    });
  };

  const cancelEdit = () => {
    setEditingId(null);
    setEditFormData({});
    setShowIconMenu(false);
  };

  const saveEdit = (id: string) => {
    if (onUpdateCategory && editFormData.name) {
       onUpdateCategory(id, editFormData);
    }
    setEditingId(null);
    setEditFormData({});
    setShowIconMenu(false);
  };

  const move = (index: number, direction: -1 | 1) => {
    if (!onReorderCategories) return;
    const newCats = [...categories];
    if (direction === -1 && index > 0) {
      [newCats[index], newCats[index - 1]] = [newCats[index - 1], newCats[index]];
    } else if (direction === 1 && index < newCats.length - 1) {
      [newCats[index], newCats[index + 1]] = [newCats[index + 1], newCats[index]];
    }
    onReorderCategories(newCats);
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="管理任務類別 & 排序" maxWidth="max-w-2xl">
      <div className="space-y-4">
        <p className="text-sm text-slate-500">提示：您可以使用上下箭頭調整類別顯示順序，或點擊鉛筆圖示編輯。</p>
        <div className="space-y-2 max-h-[50vh] overflow-y-auto pb-10">
          {categories.map((cat: Category, index: number) => {
            const isEditing = editingId === cat.id;

            if (isEditing) {
              return (
                 <div key={cat.id} className="p-3 bg-blue-50 rounded-lg border border-blue-200 gap-2 flex flex-col animate-in fade-in">
                    <div className="flex gap-2 relative">
                       {/* Icon Picker (Click to Toggle) */}
                       <div className="relative">
                          <button
                             type="button"
                             onClick={() => setShowIconMenu(!showIconMenu)}
                             className="w-9 h-9 border rounded bg-white flex items-center justify-center text-slate-700 hover:border-blue-400"
                          >
                             {getIconComponent(editFormData.icon)}
                          </button>
                          
                          {showIconMenu && (
                             <div className="absolute top-10 left-0 bg-white border shadow-xl p-2 rounded-lg w-72 z-20 flex flex-wrap gap-1 animate-in fade-in zoom-in-95">
                                 {CATEGORY_ICONS.map(ic => (
                                    <button
                                      key={ic}
                                      type="button"
                                      onClick={() => {
                                        setEditFormData({...editFormData, icon: ic});
                                        setShowIconMenu(false);
                                      }}
                                      className={`p-2 rounded hover:bg-slate-100 ${editFormData.icon === ic ? 'bg-blue-50 text-blue-600 ring-1 ring-blue-200' : 'text-slate-500'}`}
                                    >
                                       {getIconComponent(ic)}
                                    </button>
                                 ))}
                             </div>
                          )}
                       </div>

                       <input 
                         type="text" 
                         className="flex-1 p-1.5 text-sm border rounded" 
                         value={editFormData.name} 
                         onChange={e => setEditFormData({...editFormData, name: e.target.value})}
                         placeholder="類別名稱"
                       />
                       <input 
                         type="number" 
                         min="0.5"
                         step="0.5"
                         className="w-20 p-1.5 text-sm border rounded" 
                         value={editFormData.suggestedHours} 
                         onChange={e => setEditFormData({...editFormData, suggestedHours: Number(e.target.value)})}
                         placeholder="工時"
                       />
                    </div>
                    <input 
                       type="text" 
                       className="w-full p-1.5 text-sm border rounded" 
                       value={editFormData.note} 
                       onChange={e => setEditFormData({...editFormData, note: e.target.value})}
                       placeholder="注意事項 (選填)"
                    />
                    <div className="flex justify-end gap-2 mt-1">
                       <Button variant="secondary" className="px-2 py-1 h-8 text-xs" onClick={cancelEdit}>
                          取消
                       </Button>
                       <Button className="px-2 py-1 h-8 text-xs bg-blue-600 hover:bg-blue-700" onClick={() => saveEdit(cat.id)}>
                          <Save className="w-3 h-3" /> 儲存變更
                       </Button>
                    </div>
                 </div>
              );
            }

            return (
              <div key={cat.id} className="flex flex-col md:flex-row md:items-center justify-between p-3 bg-slate-50 rounded-lg border border-slate-100 gap-2">
                 <div className="flex-1">
                   <div className="flex items-center gap-2 mb-1">
                      {getCategoryIconComponent(cat.icon)}
                      <span className="font-medium text-slate-700">{cat.name}</span>
                      <span className="text-xs bg-white border px-1 rounded text-slate-500">{cat.suggestedHours}h</span>
                   </div>
                   {cat.note && (
                     <div className="text-xs text-slate-500 flex items-center gap-1">
                       <Info className="w-3 h-3" /> {cat.note}
                     </div>
                   )}
                 </div>
                 
                 <div className="flex items-center gap-1 self-end md:self-auto">
                   {onReorderCategories && (
                     <>
                       <button 
                         type="button"
                         disabled={index === 0}
                         onClick={() => move(index, -1)} 
                         className="p-1.5 text-slate-400 hover:text-blue-600 disabled:opacity-30 hover:bg-white rounded"
                       >
                         <ArrowUp className="w-4 h-4" />
                       </button>
                       <button 
                         type="button"
                         disabled={index === categories.length - 1}
                         onClick={() => move(index, 1)} 
                         className="p-1.5 text-slate-400 hover:text-blue-600 disabled:opacity-30 hover:bg-white rounded"
                       >
                         <ArrowDown className="w-4 h-4" />
                       </button>
                       <div className="w-px h-4 bg-slate-200 mx-1"></div>
                     </>
                   )}
                   {onUpdateCategory && (
                     <button onClick={() => startEdit(cat)} className="p-1.5 text-slate-400 hover:text-blue-600 hover:bg-white rounded" title="編輯類別">
                       <Pencil className="w-4 h-4" />
                     </button>
                   )}
                   <button onClick={() => onDeleteCategory(cat.id)} className="p-1.5 text-slate-400 hover:text-red-500 hover:bg-white rounded" title="刪除類別">
                     <Trash2 className="w-4 h-4" />
                   </button>
                 </div>
              </div>
            );
          })}
        </div>
        
        <form onSubmit={handleAdd} className="border-t pt-4 space-y-3">
           <label className="text-xs font-bold text-slate-400 uppercase">新增類別</label>
           
           <div className="flex gap-2 items-start">
             <div className="w-full">
                <div className="flex gap-2 mb-2">
                   <div className="flex-1">
                      <input required type="text" placeholder="類別名稱 (如: 機構設計)" className="w-full p-2 border rounded-lg text-sm" value={newCatName} onChange={e => setNewCatName(e.target.value)} />
                   </div>
                   <div className="w-24">
                      <input required type="number" min="0.5" step="0.5" placeholder="預設工時" className="w-full p-2 border rounded-lg text-sm" value={newCatHours} onChange={e => setNewCatHours(Number(e.target.value))} />
                   </div>
                </div>
                
                <input 
                  type="text" 
                  placeholder="注意事項 (選填，如: 需確認干涉檢查...)" 
                  className="w-full p-2 border rounded-lg text-sm mb-2" 
                  value={newCatNote} 
                  onChange={e => setNewCatNote(e.target.value)} 
                />

                <div className="bg-slate-50 p-2 rounded border border-slate-100">
                    <div className="text-xs text-slate-500 mb-1">選擇圖示:</div>
                    <div className="flex flex-wrap gap-1">
                        {CATEGORY_ICONS.map(ic => (
                            <button
                                key={ic}
                                type="button"
                                onClick={() => setNewCatIcon(ic)}
                                className={`p-1.5 rounded hover:bg-white border transition-all ${newCatIcon === ic ? 'bg-white border-blue-500 text-blue-600 shadow-sm' : 'border-transparent text-slate-400'}`}
                            >
                                {getIconComponent(ic)}
                            </button>
                        ))}
                    </div>
                </div>
             </div>
           </div>
           
           <div className="flex justify-end">
              <Button type="submit" variant="secondary"><Plus className="w-4 h-4" /> 新增</Button>
           </div>
        </form>
      </div>
    </Modal>
  );
};

export const OverdueListModal = ({ isOpen, onClose, tasks, users, categories, onTransferTask }: any) => {
  const overdueTasks = tasks.filter((t: Task) => t.status !== 'DONE' && new Date(t.deadline) < new Date(new Date().setHours(0,0,0,0)));

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={`逾期任務清單 (${overdueTasks.length})`} maxWidth="max-w-3xl">
       <div className="space-y-2 max-h-[60vh] overflow-y-auto">
         {overdueTasks.length > 0 ? overdueTasks.map((task: Task) => (
            <TaskItem 
              key={task.id} 
              task={task} 
              categories={categories} 
              showOwner 
              users={users} 
              onTransfer={onTransferTask ? () => onTransferTask(task) : undefined} 
            />
         )) : <p className="text-slate-400 text-center py-8">目前沒有逾期任務</p>}
       </div>
    </Modal>
  );
};

export const GeneralTaskListModal = ({ isOpen, onClose, title, tasks, users, categories, onTransferTask, onEditTask, onDeleteTask }: any) => {
  return (
    <Modal isOpen={isOpen} onClose={onClose} title={`${title} (${tasks.length})`} maxWidth="max-w-3xl">
       <div className="space-y-2 max-h-[60vh] overflow-y-auto">
         {tasks.length > 0 ? tasks.map((task: Task) => (
            <TaskItem 
              key={task.id}
              task={task} 
              categories={categories} 
              showOwner 
              users={users} 
              onEdit={onEditTask ? () => onEditTask(task) : undefined}
              onDelete={onDeleteTask ? () => onDeleteTask(task.id) : undefined}
              onTransfer={onTransferTask ? () => onTransferTask(task) : undefined}
              showLogsToggle={true}
            />
         )) : <p className="text-slate-400 text-center py-8">無相關任務</p>}
       </div>
    </Modal>
  );
};

export const TaskSearchModal = ({ isOpen, onClose, tasks, users, categories }: any) => {
  const [term, setTerm] = useState('');
  
  const filtered = term.trim() ? tasks.filter((t: Task) => 
    t.title.toLowerCase().includes(term.toLowerCase()) || 
    t.partNumber?.toLowerCase().includes(term.toLowerCase()) ||
    users.find((u:User) => u.id === t.userId)?.name.includes(term)
  ) : [];

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="搜尋任務" maxWidth="max-w-2xl">
       <div className="mb-4 relative">
         <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
         <input 
           autoFocus
           type="text" 
           className="w-full pl-10 pr-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 outline-none" 
           placeholder="輸入標題、品號或負責人搜尋..." 
           value={term} 
           onChange={e => setTerm(e.target.value)} 
         />
       </div>
       <div className="space-y-2 max-h-[50vh] overflow-y-auto">
         {filtered.map((task: Task) => (
           <TaskItem key={task.id} task={task} categories={categories} showOwner users={users} showLogsToggle={true} />
         ))}
         {term && filtered.length === 0 && <p className="text-slate-400 text-center">找不到符合的結果</p>}
       </div>
    </Modal>
  );
};

export const BatchTaskModal = ({ isOpen, onClose, onSubmit, users, categories }: any) => {
  const [globalPartNumber, setGlobalPartNumber] = useState('');
  const [globalProjectOwner, setGlobalProjectOwner] = useState(users[0]?.id || '');
  
  const [rows, setRows] = useState([
    { categoryId: categories[0]?.id || '', phase: 'P2', deadline: '', estimatedHours: categories[0]?.suggestedHours || 4, userId: users[0]?.id }
  ]);

  useEffect(() => {
    if (isOpen) {
       // Reset logic if needed
    }
  }, [isOpen, users]);

  const addRow = () => setRows([...rows, { categoryId: categories[0]?.id || '', phase: 'P2', deadline: '', estimatedHours: categories[0]?.suggestedHours || 4, userId: users[0]?.id }]);
  
  const updateRow = (idx: number, field: string, val: any) => {
    const newRows = [...rows];
    const row: any = newRows[idx];
    row[field] = val;
    
    if (field === 'categoryId') {
        const cat = categories.find((c: Category) => c.id === val);
        if (cat) {
            row.estimatedHours = cat.suggestedHours;
        }
    }
    
    setRows(newRows);
  };

  const removeRow = (idx: number) => {
     if (rows.length > 1) {
        setRows(rows.filter((_, i) => i !== idx));
     }
  };

  const handleSubmit = () => {
    if (!globalPartNumber.trim()) {
        alert('請輸入專案品號 (Part Number)');
        return;
    }

    const tasks = rows.map(r => {
       const cat = categories.find((c: Category) => c.id === r.categoryId);
       const catName = cat ? cat.name : '未分類';
       
       const title = `${catName} - ${r.phase}`;

       return {
            title: title,
            deadline: r.deadline || new Date().toISOString().split('T')[0],
            estimatedHours: r.estimatedHours,
            userId: r.userId, 
            categoryId: r.categoryId,
            priority: 'MEDIUM',
            phase: r.phase,
            receiveDate: new Date().toISOString().split('T')[0],
            status: 'TODO',
            logs: [],
            actualHours: 0,
            partNumber: globalPartNumber, 
            description: `批次建立：${title}`
       };
    });
    
    onSubmit(tasks, globalPartNumber, globalProjectOwner);
    
    setGlobalPartNumber('');
    setRows([{ categoryId: categories[0]?.id || '', phase: 'P2', deadline: '', estimatedHours: categories[0]?.suggestedHours || 4, userId: users[0]?.id }]);
    onClose();
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="批次建立任務" maxWidth="max-w-5xl">
       <div className="mb-6 bg-slate-50 p-4 rounded-lg border border-slate-200">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
             <div>
                <label className="block text-sm font-bold text-slate-700 mb-1">
                   專案品號 (Part Number) - 全局設定
                </label>
                <div className="relative">
                   <Tag className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                   <input 
                     autoFocus
                     type="text" 
                     className="w-full pl-9 pr-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 font-mono" 
                     placeholder="e.g. 805-0023-01" 
                     value={globalPartNumber} 
                     onChange={e => setGlobalPartNumber(e.target.value)} 
                   />
                </div>
             </div>
             
             <div>
                <label className="block text-sm font-bold text-slate-700 mb-1">
                   專案負責人 (Project Owner) - 全局設定
                </label>
                <div className="relative">
                   <UserIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                   <select 
                      className="w-full pl-9 pr-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
                      value={globalProjectOwner}
                      onChange={e => setGlobalProjectOwner(e.target.value)}
                   >
                      <option value="">-- 未指派 --</option>
                      {users.map((u: User) => (
                         <option key={u.id} value={u.id}>{u.name} ({u.employeeId})</option>
                      ))}
                   </select>
                </div>
             </div>
          </div>
       </div>

       <div className="overflow-x-auto min-h-[200px]">
         <table className="w-full text-sm text-left">
           <thead>
             <tr className="border-b bg-slate-50">
               <th className="pb-2 pt-2 px-2 w-48">任務類別</th>
               <th className="pb-2 pt-2 px-2 w-32">專案階段</th>
               <th className="pb-2 pt-2 px-2 w-32">期限</th>
               <th className="pb-2 pt-2 px-2 w-20">工時</th>
               <th className="pb-2 pt-2 px-2 w-32">執行負責人</th>
               <th className="pb-2 pt-2 px-2 w-10"></th>
             </tr>
           </thead>
           <tbody>
             {rows.map((row, idx) => (
               <tr key={idx} className="border-b last:border-0 hover:bg-slate-50 transition-colors">
                 <td className="p-2">
                    <select className="w-full p-1.5 border rounded" value={row.categoryId} onChange={e => updateRow(idx, 'categoryId', e.target.value)}>
                        {categories.map((c: Category) => <option key={c.id} value={c.id}>{c.name}</option>)}
                    </select>
                 </td>
                 <td className="p-2">
                    <select className="w-full p-1.5 border rounded" value={row.phase} onChange={e => updateRow(idx, 'phase', e.target.value)}>
                        <option value="P1">P1 (提案)</option>
                        <option value="P2">P2 (設計)</option>
                        <option value="P3">P3 (驗證)</option>
                        <option value="P4">P4 (結案)</option>
                        <option value="P5">P5 (變更)</option>
                    </select>
                 </td>
                 <td className="p-2">
                    <input type="date" className="w-full p-1.5 border rounded" value={row.deadline} onChange={e => updateRow(idx, 'deadline', e.target.value)} />
                 </td>
                 <td className="p-2">
                    <input type="number" step="0.5" className="w-full p-1.5 border rounded" value={row.estimatedHours} onChange={e => updateRow(idx, 'estimatedHours', Number(e.target.value))} />
                 </td>
                 <td className="p-2">
                   <select className="w-full p-1.5 border rounded" value={row.userId} onChange={e => updateRow(idx, 'userId', e.target.value)}>
                     {users.map((u: User) => <option key={u.id} value={u.id}>{u.name}</option>)}
                   </select>
                 </td>
                 <td className="p-2 text-center">
                    {rows.length > 1 && (
                        <button onClick={() => removeRow(idx)} className="text-slate-400 hover:text-red-500">
                            <Trash2 className="w-4 h-4" />
                        </button>
                    )}
                 </td>
               </tr>
             ))}
           </tbody>
         </table>
       </div>
       <div className="mt-4 flex gap-2">
         <Button variant="secondary" onClick={addRow}><Plus className="w-4 h-4" /> 新增任務列</Button>
         <div className="flex-1"></div>
         <Button variant="secondary" onClick={onClose}>取消</Button>
         <Button onClick={handleSubmit}>建立任務 ({rows.length})</Button>
       </div>
    </Modal>
  );
};

export const ApprovalListModal = ({ isOpen, onClose, tasks, users, onApprove, onReject }: any) => {
  const pendingTasks = tasks.filter((t: Task) => t.pendingChange);

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="待簽核項目" maxWidth="max-w-3xl">
      <div className="space-y-4 max-h-[60vh] overflow-y-auto">
         {pendingTasks.length > 0 ? pendingTasks.map((task: Task) => {
           const req = task.pendingChange!;
           const requester = users.find((u: User) => u.id === req.requesterId)?.name || 'Unknown';
           
           return (
             <div key={task.id} className="p-4 border border-orange-200 bg-orange-50 rounded-lg">
                <div className="flex justify-between items-start mb-2">
                   <h4 className="font-bold text-slate-800">{task.title}</h4>
                   <span className="text-xs bg-orange-200 text-orange-800 px-2 py-0.5 rounded-full">日期變更</span>
                </div>
                <div className="text-sm text-slate-600 mb-3 space-y-1">
                   <p>申請人: {requester}</p>
                   <p>原因: <span className="font-medium">{req.reason}</span></p>
                   <div className="flex gap-4 mt-2 bg-white p-2 rounded border border-orange-100">
                      <div>
                        <div className="text-xs text-slate-400">原定日期</div>
                        <div className="text-slate-500 line-through">{task.deadline}</div>
                      </div>
                      <ArrowRightLeft className="w-4 h-4 text-slate-300 self-center" />
                      <div>
                        <div className="text-xs text-orange-400 font-bold">新日期</div>
                        <div className="text-orange-600 font-bold">{req.newDeadline}</div>
                      </div>
                   </div>
                </div>
                <div className="flex justify-end gap-2">
                   <Button variant="secondary" onClick={() => onReject(task.id)} className="text-red-600 hover:bg-red-50"><X className="w-4 h-4" /> 駁回</Button>
                   <Button onClick={() => onApprove(task.id)} className="bg-emerald-600 hover:bg-emerald-700"><CheckCircle2 className="w-4 h-4" /> 核准變更</Button>
                </div>
             </div>
           );
         }) : (
           <div className="text-center py-12 text-slate-400">
             <CheckCircle2 className="w-12 h-12 mx-auto mb-2 opacity-20" />
             <p>目前沒有待簽核的項目</p>
           </div>
         )}
      </div>
    </Modal>
  );
};

export const VerificationCompletionModal = ({ isOpen, onClose, onConfirm, taskTitle }: { isOpen: boolean; onClose: () => void; onConfirm: (count: number, achieved: number) => void; taskTitle: string }) => {
  const [count, setCount] = useState(0);
  const [achieved, setAchieved] = useState(0);

  useEffect(() => {
    if (isOpen) {
        setCount(0);
        setAchieved(0);
    }
  }, [isOpen]);

  const rate = count > 0 ? Math.round((achieved / count) * 100) : 0;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onConfirm(count, achieved);
    onClose();
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="試模/驗證結果回報" zIndex="z-[70]">
       <form onSubmit={handleSubmit} className="space-y-6">
          <div className="bg-slate-50 p-4 rounded-lg border border-slate-200">
             <div className="text-xs text-slate-500 mb-1">正在結案任務</div>
             <div className="font-bold text-slate-800">{taskTitle}</div>
          </div>

          <div className="grid grid-cols-2 gap-4">
             <div>
                <label className="block text-sm font-bold text-slate-700 mb-1">DV 項目總數</label>
                <input 
                  required
                  type="number" 
                  min="1"
                  className="w-full p-2 border rounded-lg text-center font-mono text-lg"
                  value={count || ''}
                  onChange={e => setCount(Number(e.target.value))}
                />
             </div>
             <div>
                <label className="block text-sm font-bold text-slate-700 mb-1">DV 達成項目數</label>
                <input 
                  required
                  type="number" 
                  min="0"
                  max={count}
                  className="w-full p-2 border rounded-lg text-center font-mono text-lg"
                  value={achieved || ''}
                  onChange={e => setAchieved(Number(e.target.value))}
                />
             </div>
          </div>

          <div className="bg-indigo-50 p-4 rounded-xl flex items-center justify-between border border-indigo-100">
             <div className="flex items-center gap-2 text-indigo-800">
                <Microscope className="w-5 h-5" />
                <span className="font-bold">設計成功率</span>
             </div>
             <div className="text-3xl font-black text-indigo-600">
                {rate}<span className="text-lg">%</span>
             </div>
          </div>

          <div className="flex justify-end gap-2 pt-2">
             <Button variant="secondary" onClick={onClose}>暫不結案</Button>
             <Button type="submit" disabled={count <= 0 || achieved > count}>確認結案並儲存</Button>
          </div>
       </form>
    </Modal>
  );
};

export const ReportModal = ({ 
  isOpen, 
  onClose, 
  currentUser, 
  users, 
  tasks,
  categories = [] 
}: { 
  isOpen: boolean; 
  onClose: () => void; 
  currentUser: User; 
  users: User[]; 
  tasks: Task[]; 
  categories?: Category[];
}) => {
  const [reportType, setReportType] = useState<'DAILY' | 'WEEKLY' | 'MONTHLY' | 'SCHEDULE_ACHIEVEMENT' | 'DESIGN_ACHIEVEMENT' | 'DESIGN_CHANGE_ACHIEVEMENT' | 'ALL_TASKS'>('DAILY');
  const [targetUserId, setTargetUserId] = useState(currentUser.id); 
  const [targetCategoryId, setTargetCategoryId] = useState('ALL'); 
  const [selectedDate, setSelectedDate] = useState(new Date());

  useEffect(() => {
    if (isOpen) {
      setTargetUserId(currentUser.id);
      setSelectedDate(new Date());
      setTargetCategoryId('ALL');
    }
  }, [isOpen, currentUser.id]);

  const dateRange = useMemo(() => {
    const start = new Date(selectedDate);
    const end = new Date(selectedDate);

    if (reportType === 'DAILY') {
      start.setHours(0,0,0,0);
      end.setHours(23,59,59,999);
    } else if (reportType === 'WEEKLY') {
      const day = start.getDay();
      const diff = start.getDate() - day + (day === 0 ? -6 : 1); 
      start.setDate(diff);
      start.setHours(0,0,0,0);
      
      end.setDate(start.getDate() + 6);
      end.setHours(23,59,59,999);
    } else if (reportType === 'MONTHLY' || reportType === 'SCHEDULE_ACHIEVEMENT' || reportType === 'DESIGN_ACHIEVEMENT' || reportType === 'DESIGN_CHANGE_ACHIEVEMENT' || reportType === 'ALL_TASKS') {
      start.setDate(1);
      start.setHours(0,0,0,0);
      
      end.setMonth(start.getMonth() + 1);
      end.setDate(0);
      end.setHours(23,59,59,999);
    }
    return { start, end };
  }, [reportType, selectedDate]);

  const reportData = useMemo(() => {
    let usersToProcess: User[] = [];
    if (targetUserId === 'ALL') {
       if (reportType === 'DESIGN_ACHIEVEMENT' || reportType === 'SCHEDULE_ACHIEVEMENT' || reportType === 'DESIGN_CHANGE_ACHIEVEMENT' || reportType === 'ALL_TASKS') {
          usersToProcess = users;
       } else {
          usersToProcess = users.filter(u => u.role !== 'ADMIN');
       }
    } else {
      const u = users.find(u => u.id === targetUserId);
      if (u) usersToProcess = [u];
    }

    const results = usersToProcess.map(targetUser => {
        const groupedData = new Map<string, { 
          task: Task, 
          logs: TaskLog[], 
          totalHours: number,
          completedInPeriod: boolean 
        }>();
        
        let userTotalHours = 0;

        tasks.forEach(task => {
          if (task.userId === targetUser.id) {
            
            if (reportType === 'ALL_TASKS') {
                 if (targetCategoryId !== 'ALL' && task.categoryId !== targetCategoryId) return;

                 const deadline = parseDateLocal(task.deadline);
                 const received = parseDateLocal(task.receiveDate);
                 const completed = task.completedDate ? parseDateLocal(task.completedDate) : null;
                 
                 const inRange = (d: Date) => d.getTime() >= dateRange.start.getTime() && d.getTime() <= dateRange.end.getTime();
                 
                 let include = false;
                 if (inRange(deadline)) include = true;
                 if (inRange(received)) include = true;
                 if (completed && inRange(completed)) include = true;

                 if (include) {
                    if (!groupedData.has(task.id)) {
                        groupedData.set(task.id, { task, logs: [], totalHours: 0, completedInPeriod: false });
                    }
                 }
                 return;
            }

            if (reportType === 'DESIGN_CHANGE_ACHIEVEMENT') {
              const taskCat = categories.find(c => c.id === task.categoryId);
              if (taskCat && taskCat.name.includes('設計變更')) {
                  const dateToCheckStr = task.completedDate || task.deadline;
                  const dateToCheck = parseDateLocal(dateToCheckStr);
                  
                  if (dateToCheck.getTime() >= dateRange.start.getTime() && 
                      dateToCheck.getTime() <= dateRange.end.getTime()) {
                      
                      if (!groupedData.has(task.id)) {
                          groupedData.set(task.id, { task, logs: [], totalHours: 0, completedInPeriod: false });
                      }
                  }
              }
              return;
            }

            if (reportType === 'DESIGN_ACHIEVEMENT') {
               const taskCat = categories.find(c => c.id === task.categoryId);
               if (taskCat) {
                   const name = taskCat.name.toLowerCase();
                   const isTestReport = name.includes('試模') || name.includes('測試') || name.includes('驗證') || name.includes('test');
                   
                   if (isTestReport) {
                      const dateToCheckStr = task.completedDate || task.deadline;
                      const dateToCheck = parseDateLocal(dateToCheckStr);
                      
                      if (dateToCheck.getTime() >= dateRange.start.getTime() && 
                          dateToCheck.getTime() <= dateRange.end.getTime()) {
                          
                          if (!groupedData.has(task.id)) {
                              groupedData.set(task.id, { task, logs: [], totalHours: 0, completedInPeriod: false });
                          }
                      }
                   }
               }
               return;
            }

            if (reportType === 'SCHEDULE_ACHIEVEMENT') {
                 if (targetCategoryId !== 'ALL' && task.categoryId !== targetCategoryId) {
                     return;
                 }

                 const deadlineDate = parseDateLocal(task.deadline);
                 if (deadlineDate.getTime() >= dateRange.start.getTime() && 
                     deadlineDate.getTime() <= dateRange.end.getTime()) {
                     
                     if (!groupedData.has(task.id)) {
                        groupedData.set(task.id, { task, logs: [], totalHours: 0, completedInPeriod: false });
                     }
                 }
                 return;
            }

            const relevantLogs = task.logs.filter(log => {
              const logDate = parseDateLocal(log.date);
              return logDate.getTime() >= dateRange.start.getTime() && 
                     logDate.getTime() <= dateRange.end.getTime();
            });

            let completedInPeriod = false;
            if (task.status === 'DONE' && task.completedDate) {
              const compDate = parseDateLocal(task.completedDate);
              if (compDate.getTime() >= dateRange.start.getTime() && 
                  compDate.getTime() <= dateRange.end.getTime()) {
                completedInPeriod = true;
              }
            }

            if (relevantLogs.length > 0 || completedInPeriod) {
               if (!groupedData.has(task.id)) {
                 groupedData.set(task.id, { 
                   task, 
                   logs: [], 
                   totalHours: 0,
                   completedInPeriod: false
                 });
               }
               const entry = groupedData.get(task.id)!;
               
               entry.logs.push(...relevantLogs);
               entry.totalHours += relevantLogs.reduce((acc, l) => acc + l.hoursSpent, 0);
               if (completedInPeriod) entry.completedInPeriod = true;

               userTotalHours += relevantLogs.reduce((acc, l) => acc + l.hoursSpent, 0);
            }
          }
        });

        return {
          user: targetUser,
          entries: Array.from(groupedData.values()),
          userTotalHours
        };
    }); 

    const grandTotalTeamHours = results.reduce((acc, curr) => acc + curr.userTotalHours, 0);

    return {
      results,
      grandTotalTeamHours,
      range: dateRange,
      isTeamReport: targetUserId === 'ALL'
    };
  }, [tasks, targetUserId, dateRange, users, reportType, targetCategoryId, categories]);

  const getTaskPerformance = (task: Task) => {
      const deadline = parseDateLocal(task.deadline);
      
      if (task.status === 'DONE' && task.completedDate) {
        const completed = parseDateLocal(task.completedDate);
        if (completed.getTime() < deadline.getTime()) return '提早完成';
        if (completed.getTime() === deadline.getTime()) return '準時完成';
        return '逾期結案';
      } else {
         const today = new Date();
         today.setHours(0,0,0,0);
         if (today.getTime() > deadline.getTime()) return '逾期未完';
         return '進行中';
      }
  };

  const reportText = useMemo(() => {
    if (!reportData) return '';
    
    const formatDate = (d: Date) => d.toISOString().split('T')[0];
    const rangeStr = `${formatDate(reportData.range.start)} ~ ${formatDate(reportData.range.end)}`;

    if (reportType === 'ALL_TASKS') {
      let text = `📅 【全部任務明細表】\n`;
      text += `🕒 統計區間：${rangeStr}\n`;
      const catName = targetCategoryId === 'ALL' ? '全部類別' : categories.find(c => c.id === targetCategoryId)?.name;
      text += `📂 篩選類別：${catName}\n`;
      text += `------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n`;
      text += `品號          | 任務標題             | 狀態     | 負責人   | 任務類別       | 階段 | 接收日      | 截止日      | 完成日      | 預估 | 實際 | 優先級 | DV(總/成) | 變更單號\n`;
      text += `------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n`;

      let hasData = false;
      reportData.results.forEach(userData => {
        userData.entries.forEach(entry => {
            const t = entry.task;
            const categoryName = categories.find(c => c.id === t.categoryId)?.name || '未分類';
            const ownerName = users.find(u => u.id === t.userId)?.name || 'Unknown';
            const pn = t.partNumber || '-';
            const title = t.title.substring(0, 15);
            const status = getStatusLabel(t.status);
            const phase = getPhaseLabel(t.phase).split(' ')[0]; // P1
            const dv = (t.dvCount !== undefined) ? `${t.dvCount}/${t.dvAchieved||0}` : '-';
            const change = t.changeOrderNumber || '-';
            
            text += `${pn.padEnd(13)} | ${title.padEnd(20)} | ${status.padEnd(8)} | ${ownerName.padEnd(8)} | ${categoryName.substring(0,8).padEnd(14)} | ${phase} | ${t.receiveDate} | ${t.deadline} | ${t.completedDate||'-'} | ${t.estimatedHours} | ${t.actualHours} | ${t.priority} | ${dv.padEnd(9)} | ${change}\n`;
            hasData = true;
        });
      });
      if (!hasData) text += `(此區間無任務資料)\n`;
      return text;
    }
    
    if (reportType === 'DESIGN_CHANGE_ACHIEVEMENT') {
      let text = `📅 【設計變更次數統計報表】\n`;
      text += `🕒 統計區間：${rangeStr}\n`;
      text += `------------------------------------------------------------------------------------------------------------------------------------\n`;
      text += `品號          | 任務類別       | 負責人   | 變更單號    | 變更分類        | 變更分析        | 任務描述          | 變更次數 | 預計完成 | 實際完成\n`;
      text += `------------------------------------------------------------------------------------------------------------------------------------\n`;

      let hasData = false;
      reportData.results.forEach(userData => {
        userData.entries.forEach(entry => {
          const t = entry.task;
          const categoryName = categories.find(c => c.id === t.categoryId)?.name || '未分類';
          const ownerName = users.find(u => u.id === t.userId)?.name || 'Unknown';
          const pn = t.partNumber || '-';
          const orderNo = t.changeOrderNumber || '-';
          const changeCat = t.changeCategory || '-';
          const changeAnl = t.changeAnalysis || '-';
          const desc = t.description ? t.description.replace(/\n/g, ' ') : '-';
          const count = t.changeCount || 0;
          const estDate = t.deadline || '-';
          const actDate = t.completedDate || '-';

          text += `${pn.padEnd(13)} | ${categoryName.substring(0,8).padEnd(10)} | ${ownerName.padEnd(8)} | ${orderNo.padEnd(10)} | ${changeCat.padEnd(12)} | ${changeAnl.padEnd(12)} | ${desc.substring(0, 15).padEnd(17)} | ${count.toString().padEnd(8)} | ${estDate} | ${actDate}\n`;
          hasData = true;
        });
      });

      if (!hasData) text += `(此區間無相關設計變更任務)\n`;
      return text;
    }

    if (reportType === 'DESIGN_ACHIEVEMENT') {
      let text = `📅 【設計成功率報表】\n`;
      text += `🕒 統計區間：${rangeStr}\n`;
      text += `--------------------------------------------------------------------------------------------------------\n`;
      text += `品號          | 任務標題             | 任務類別       | 負責人   | DV項目數 | DV達成項目數 | 設計成功率\n`;
      text += `--------------------------------------------------------------------------------------------------------\n`;
      
      let hasData = false;
      reportData.results.forEach(userData => {
          userData.entries.forEach(entry => {
             const t = entry.task;
             const categoryName = categories.find(c => c.id === t.categoryId)?.name || '未分類';
             const ownerName = users.find(u => u.id === t.userId)?.name || 'Unknown';
             const dvTotal = t.dvCount || 0;
             const dvDone = t.dvAchieved || 0;
             const rate = dvTotal > 0 ? Math.round((dvDone / dvTotal) * 100) : 0;
             const pn = t.partNumber || 'N/A';
             const title = t.title.substring(0, 15);
             
             text += `${pn.padEnd(13)} | ${title.padEnd(20)} | ${categoryName.substring(0,8).padEnd(10)}... | ${ownerName.padEnd(8)} | ${dvTotal.toString().padEnd(6)} | ${dvDone.toString().padEnd(6)} | ${rate}%\n`;
             hasData = true;
          });
      });
      
      if (!hasData) text += `(此區間無相關試模檢驗任務)\n`;
      return text;
    }

    if (reportType === 'SCHEDULE_ACHIEVEMENT') {
        let text = `📅 【日程達成率報表】\n`;
        text += `🕒 統計區間：${rangeStr}\n`;
        
        const catName = targetCategoryId === 'ALL' ? '全部類別' : categories.find(c => c.id === targetCategoryId)?.name;
        text += `📂 篩選類別：${catName}\n`;
        
        let totalTasks = 0;
        let onTimeTasks = 0;
        let lines: string[] = [];

        reportData.results.forEach(userData => {
            userData.entries.forEach(entry => {
                const t = entry.task;
                const categoryName = categories.find(c => c.id === t.categoryId)?.name || '未分類';
                const ownerName = users.find(u => u.id === t.userId)?.name || 'Unknown';
                const actualDate = t.completedDate || '(未完成)';
                
                totalTasks++;
                const perf = getTaskPerformance(t);
                if (perf === '提早完成' || perf === '準時完成') {
                    onTimeTasks++;
                }

                const pn = t.partNumber || 'N/A';
                lines.push(`• ${pn.padEnd(12)} | ${categoryName.substring(0,8)}... | ${ownerName} | 預: ${t.deadline} | 實: ${actualDate} | 預時: ${t.estimatedHours} | 實時: ${t.actualHours} (${perf})`);
            });
        });

        const rate = totalTasks > 0 ? Math.round((onTimeTasks / totalTasks) * 100) : 0;
        
        text += `📊 總計任務: ${totalTasks} | 準時達成: ${onTimeTasks} | 達成率: ${rate}%\n`;
        text += `--------------------------------------------------\n`;
        text += `格式: 品號 | 任務類別 | 負責人 | 預計完成 | 實際完成 | 預計工時 | 實際工時\n`;
        text += `--------------------------------------------------\n`;
        
        if (lines.length > 0) {
            text += lines.join('\n');
        } else {
            text += `(此區間無應完成之任務)\n`;
        }
        return text;
    }

    let title = '';
    if (reportType === 'DAILY') title = '工作日報';
    if (reportType === 'WEEKLY') title = '工作週報';
    if (reportType === 'MONTHLY') title = '工作月報';

    let text = `📅 【${title}】\n`;
    
    if (reportData.isTeamReport) {
      text += `👥 團隊彙整 (All Members)\n`;
      text += `🕒 區間：${rangeStr}\n`;
      text += `📊 團隊總工時：${reportData.grandTotalTeamHours} 小時\n`;
      text += `--------------------------------------------------\n\n`;
    } else if (reportData.results.length > 0) {
      text += `👤 人員：${reportData.results[0].user.name}\n`;
      text += `🕒 區間：${rangeStr}\n\n`;
    } else {
       text += `🕒 區間：${rangeStr}\n\n`;
       text += `(此區間無相關工作紀錄)\n`;
       return text;
    }

    reportData.results.forEach((userData) => {
        if (reportData.isTeamReport) {
           text += `🔹 成員：${userData.user.name} (工時: ${userData.userTotalHours}h)\n`;
           text += `==============================================\n`;
        }

        const completedItems = userData.entries.filter(e => e.completedInPeriod);
        const activeItems = userData.entries.filter(e => !e.completedInPeriod);

        if (!reportData.isTeamReport) {
          text += `📊 【重點摘要】\n`;
          text += `--------------------------------------------------\n`;
          text += `• 投入總工時：${userData.userTotalHours} 小時\n`;
          text += `• 完成任務數：${completedItems.length}\n`;
          text += `• 進行中任務：${activeItems.length}\n`;
          text += `--------------------------------------------------\n\n`;
        }

        if (completedItems.length > 0) {
          text += `✅ 【已完成項目】\n`;
          text += `--------------------------------------------------\n`;
          completedItems.forEach((entry, index) => {
            text += `${index + 1}. ${entry.task.title}`;
            if (entry.task.partNumber) text += ` (PN: ${entry.task.partNumber})`;
            text += `\n`;
            text += `   [${getPhaseLabel(entry.task.phase)}] | 總實際工時: ${entry.task.actualHours}h\n`;
            if (entry.task.completedDate) {
              text += `   > 於 ${entry.task.completedDate} 結案 (${getTaskPerformance(entry.task)})\n`;
            }
            text += `\n`;
          });
        }

        if (activeItems.length > 0) {
          const sectionTitle = completedItems.length > 0 ? `▶️ 【進行中項目】` : `▶️ 【工作項目】`;
          text += `${sectionTitle}\n`;
          text += `--------------------------------------------------\n`;
          activeItems.forEach((entry, index) => {
            text += `${index + 1}. ${entry.task.title}`;
            if (entry.task.partNumber) text += ` (PN: ${entry.task.partNumber})`;
            text += `\n`;

            if (entry.task.description) {
               text += `   📝 說明: ${entry.task.description}\n`;
            }

            text += `   狀態: ${getStatusLabel(entry.task.status)} | 本期工時: ${entry.totalHours}h\n`;
            
            if (entry.logs.length > 0) {
              text += `   📋 日誌:\n`;
              entry.logs.sort((a,b) => parseDateLocal(a.date).getTime() - parseDateLocal(b.date).getTime()).forEach(log => {
                text += `     • ${log.content} (${log.hoursSpent}h)\n`;
              });
            } else {
              text += `   (本期無工時紀錄，僅狀態更新)\n`;
            }
            text += `\n`;
          });
        }

        if (completedItems.length === 0 && activeItems.length === 0) {
           text += `   (無紀錄)\n`;
        }
        
        text += `\n`;
    });
    
    return text;
  }, [reportData, reportType, categories, users, targetCategoryId]);

  const handleCopy = () => {
    navigator.clipboard.writeText(reportText);
    alert('報表內容已複製到剪貼簿！');
  };

  const handleDownload = () => {
     try {
      if (reportData.results.length === 0 && reportType !== 'SCHEDULE_ACHIEVEMENT' && reportType !== 'DESIGN_ACHIEVEMENT' && reportType !== 'DESIGN_CHANGE_ACHIEVEMENT' && reportType !== 'ALL_TASKS') {
          alert("無資料可匯出");
          return;
      }

      const formatDate = (d: Date) => d.toISOString().split('T')[0];
      const rangeStr = `${formatDate(reportData.range.start)}~${formatDate(reportData.range.end)}`;
      
      let fileName = targetUserId === 'ALL' 
          ? `Team_Report_${rangeStr}` 
          : `${reportData.results[0]?.user.name}_Report_${rangeStr}`;

      if (reportType === 'SCHEDULE_ACHIEVEMENT') {
        fileName = `Schedule_Achievement_Rate_${rangeStr}`;
      } else if (reportType === 'DESIGN_ACHIEVEMENT') {
        fileName = `Design_Success_Rate_${rangeStr}`;
      } else if (reportType === 'DESIGN_CHANGE_ACHIEVEMENT') {
        fileName = `Design_Change_Statistics_${rangeStr}`;
      } else if (reportType === 'ALL_TASKS') {
        fileName = `All_Tasks_Detail_${rangeStr}`;
      }

      let tableBody = '';
      let tableHeader = '';

      if (reportType === 'ALL_TASKS') {
        tableHeader = `
          <tr>
              <th style="background-color: #0f172a; color: white;">品號</th>
              <th style="background-color: #0f172a; color: white;">標題</th>
              <th style="background-color: #0f172a; color: white;">描述</th>
              <th style="background-color: #0f172a; color: white;">類別</th>
              <th style="background-color: #0f172a; color: white;">負責人</th>
              <th style="background-color: #0f172a; color: white;">狀態</th>
              <th style="background-color: #0f172a; color: white;">階段</th>
              <th style="background-color: #0f172a; color: white;">優先級</th>
              <th style="background-color: #0f172a; color: white;">接收日</th>
              <th style="background-color: #0f172a; color: white;">截止日</th>
              <th style="background-color: #0f172a; color: white;">完成日</th>
              <th style="background-color: #0f172a; color: white;">預估工時</th>
              <th style="background-color: #0f172a; color: white;">實際工時</th>
              <th style="background-color: #0f172a; color: white;">DV總數</th>
              <th style="background-color: #0f172a; color: white;">DV達成</th>
              <th style="background-color: #0f172a; color: white;">變更單號</th>
          </tr>
        `;

        reportData.results.forEach(userData => {
          userData.entries.forEach(entry => {
             const t = entry.task;
             const categoryName = categories.find(c => c.id === t.categoryId)?.name || '未分類';
             const ownerName = users.find(u => u.id === t.userId)?.name || 'Unknown';
             
             tableBody += `
                <tr>
                  <td>${t.partNumber || ''}</td>
                  <td>${t.title}</td>
                  <td>${t.description || ''}</td>
                  <td>${categoryName}</td>
                  <td>${ownerName}</td>
                  <td>${getStatusLabel(t.status)}</td>
                  <td>${getPhaseLabel(t.phase)}</td>
                  <td>${t.priority}</td>
                  <td>${t.receiveDate}</td>
                  <td>${t.deadline}</td>
                  <td>${t.completedDate || ''}</td>
                  <td>${t.estimatedHours}</td>
                  <td>${t.actualHours}</td>
                  <td>${t.dvCount || ''}</td>
                  <td>${t.dvAchieved || ''}</td>
                  <td>${t.changeOrderNumber || ''}</td>
                </tr>
             `;
          });
        });
      } else if (reportType === 'DESIGN_CHANGE_ACHIEVEMENT') {
        tableHeader = `
          <tr>
              <th style="background-color: #f97316; color: white;">品號</th>
              <th style="background-color: #f97316; color: white;">任務類別</th>
              <th style="background-color: #f97316; color: white;">負責人</th>
              <th style="background-color: #f97316; color: white;">變更單號</th>
              <th style="background-color: #f97316; color: white;">變更分類</th>
              <th style="background-color: #f97316; color: white;">變更分析</th>
              <th style="background-color: #f97316; color: white;">任務描述</th>
              <th style="background-color: #f97316; color: white;">變更次數</th>
              <th style="background-color: #f97316; color: white;">預計完成</th>
              <th style="background-color: #f97316; color: white;">實際完成</th>
          </tr>
        `;
        reportData.results.forEach(userData => {
          userData.entries.forEach(entry => {
            const t = entry.task;
            const categoryName = categories.find(c => c.id === t.categoryId)?.name || '未分類';
            const ownerName = users.find(u => u.id === t.userId)?.name || 'Unknown';
            const pn = t.partNumber || '-';
            const orderNo = t.changeOrderNumber || '-';
            const changeCat = t.changeCategory || '-';
            const changeAnl = t.changeAnalysis || '-';
            const desc = t.description || '-';
            const count = t.changeCount || 0;
            const estDate = t.deadline || '-';
            const actDate = t.completedDate || '-';

            tableBody += `
                <tr>
                  <td>${pn}</td>
                  <td>${categoryName}</td>
                  <td>${ownerName}</td>
                  <td>${orderNo}</td>
                  <td>${changeCat}</td>
                  <td>${changeAnl}</td>
                  <td>${desc}</td>
                  <td>${count}</td>
                  <td>${estDate}</td>
                  <td>${actDate}</td>
                </tr>
            `;
          });
        });
      } else if (reportType === 'DESIGN_ACHIEVEMENT') {
        tableHeader = `
          <tr>
              <th style="background-color: #4f46e5; color: white;">品號</th>
              <th style="background-color: #4f46e5; color: white;">任務標題</th>
              <th style="background-color: #4f46e5; color: white;">任務類別</th>
              <th style="background-color: #4f46e5; color: white;">負責人</th>
              <th style="background-color: #4f46e5; color: white;">DV項目數</th>
              <th style="background-color: #4f46e5; color: white;">DV達成項目數</th>
              <th style="background-color: #4f46e5; color: white;">設計成功率</th>
          </tr>
        `;
        
        reportData.results.forEach(userData => {
          userData.entries.forEach(entry => {
             const t = entry.task;
             const categoryName = categories.find(c => c.id === t.categoryId)?.name || '未分類';
             const ownerName = users.find(u => u.id === t.userId)?.name || 'Unknown';
             const dvTotal = t.dvCount || 0;
             const dvDone = t.dvAchieved || 0;
             const rate = dvTotal > 0 ? Math.round((dvDone / dvTotal) * 100) : 0;
             const partNumber = t.partNumber || '-';

             tableBody += `
                <tr>
                  <td>${partNumber}</td>
                  <td>${t.title}</td>
                  <td>${categoryName}</td>
                  <td>${ownerName}</td>
                  <td>${dvTotal}</td>
                  <td>${dvDone}</td>
                  <td style="font-weight:bold; color: ${rate >= 100 ? '#16a34a' : '#2563eb'}">${rate}%</td>
                </tr>
             `;
          });
        });

      } else {
         // Default Report Headers
         tableHeader = `
            <tr>
              <th style="background-color: #2563eb; color: white; width: 120px;">品號</th>
              <th style="background-color: #2563eb; color: white; width: 150px;">任務類別</th>
              <th style="background-color: #2563eb; color: white; width: 100px;">負責人</th>
              <th style="background-color: #2563eb; color: white; width: 120px;">預計完成</th>
              <th style="background-color: #2563eb; color: white; width: 120px;">實際完成</th>
              <th style="background-color: #2563eb; color: white; width: 80px;">預計工時</th>
              <th style="background-color: #2563eb; color: white; width: 80px;">實際工時</th>
              <th style="background-color: #2563eb; color: white; width: 100px;">狀態</th>
            </tr>
         `;

         reportData.results.forEach(userData => {
          userData.entries.forEach(entry => {
              const t = entry.task;
              const categoryName = categories.find(c => c.id === t.categoryId)?.name || '未分類';
              const ownerName = users.find(u => u.id === t.userId)?.name || 'Unknown';
              const actualDate = t.completedDate || '-';
              const perf = getTaskPerformance(t);
              const partNumber = t.partNumber || '-';

              let perfColor = '#333';
              if (perf.includes('逾期')) perfColor = '#dc2626';
              if (perf.includes('提早') || perf.includes('準時')) perfColor = '#16a34a';

              tableBody += `
                  <tr>
                    <td>${partNumber}</td>
                    <td>${categoryName}</td>
                    <td>${ownerName}</td>
                    <td>${t.deadline}</td>
                    <td>${actualDate}</td>
                    <td>${t.estimatedHours}</td>
                    <td>${t.actualHours}</td>
                    <td style="color:${perfColor}; font-weight:bold;">${perf}</td>
                  </tr>
              `;
          });
         });
      }

      const tableContent = `
        <table>
          <thead>
            ${tableHeader}
          </thead>
          <tbody>
            ${tableBody || '<tr><td colspan="15" style="text-align:center;">無資料</td></tr>'}
          </tbody>
        </table>
      `;

      const excelTemplate = `
        <html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">
        <head>
        <meta http-equiv="content-type" content="application/vnd.ms-excel; charset=UTF-8">
        <!--[if gte mso 9]>
        <xml>
        <x:ExcelWorkbook>
        <x:ExcelWorksheets>
        <x:ExcelWorksheet>
        <x:Name>報表</x:Name>
        <x:WorksheetOptions>
        <x:DisplayGridlines/>
        </x:WorksheetOptions>
        </x:ExcelWorksheet>
        </x:ExcelWorksheets>
        </x:ExcelWorkbook>
        </xml>
        <![endif]-->
        <style>
          table { border-collapse: collapse; width: 100%; }
          th { border: 1px solid #333; padding: 8px; text-align: center; }
          td { border: 1px solid #ddd; padding: 8px; vertical-align: top; mso-number-format:"\@"; }
        </style>
        </head>
        <body>
          ${tableContent}
        </body>
        </html>
      `;

      const blob = new Blob([excelTemplate], { type: 'application/vnd.ms-excel' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `${fileName}.xls`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

    } catch (e) {
      console.error(e);
      alert("匯出失敗，請稍後再試。");
    }
  };

  const shiftDate = (direction: 'prev' | 'next') => {
    const newDate = new Date(selectedDate);
    if (reportType === 'DAILY') {
      newDate.setDate(newDate.getDate() + (direction === 'next' ? 1 : -1));
    } else if (reportType === 'WEEKLY') {
      newDate.setDate(newDate.getDate() + (direction === 'next' ? 7 : -7));
    } else if (reportType === 'MONTHLY' || reportType === 'SCHEDULE_ACHIEVEMENT' || reportType === 'DESIGN_ACHIEVEMENT' || reportType === 'DESIGN_CHANGE_ACHIEVEMENT' || reportType === 'ALL_TASKS') {
      newDate.setMonth(newDate.getMonth() + (direction === 'next' ? 1 : -1));
    }
    setSelectedDate(newDate);
  };

  if (!isOpen) return null;

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="工時統計報表" maxWidth="max-w-4xl">
      <div className="flex flex-col md:flex-row gap-6 h-[70vh]">
        <div className="w-full md:w-64 space-y-6 border-r border-slate-100 pr-0 md:pr-4 overflow-y-auto">
          
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-400 uppercase">報表類型</label>
            <div className="flex flex-col gap-1">
               <div className="flex flex-col gap-1">
                  <button onClick={() => setReportType('DAILY')} className={`px-3 py-2 rounded-lg text-sm text-left flex items-center gap-2 ${reportType === 'DAILY' ? 'bg-blue-50 text-blue-700 font-bold' : 'text-slate-600 hover:bg-slate-50'}`}>
                    個人日報 (Daily)
                  </button>
                  <button onClick={() => setReportType('WEEKLY')} className={`px-3 py-2 rounded-lg text-sm text-left flex items-center gap-2 ${reportType === 'WEEKLY' ? 'bg-blue-50 text-blue-700 font-bold' : 'text-slate-600 hover:bg-slate-50'}`}>
                    週報彙整 (Weekly)
                  </button>
                  <button onClick={() => setReportType('MONTHLY')} className={`px-3 py-2 rounded-lg text-sm text-left flex items-center gap-2 ${reportType === 'MONTHLY' ? 'bg-blue-50 text-blue-700 font-bold' : 'text-slate-600 hover:bg-slate-50'}`}>
                    月報統計 (Monthly)
                  </button>
                  <div className="border-t border-slate-100 my-1"></div>
                  <button onClick={() => { setReportType('SCHEDULE_ACHIEVEMENT'); if (currentUser.role === 'ADMIN') setTargetUserId('ALL'); }} className={`px-3 py-2 rounded-lg text-sm text-left flex items-center gap-2 ${reportType === 'SCHEDULE_ACHIEVEMENT' ? 'bg-blue-50 text-blue-700 font-bold' : 'text-slate-600 hover:bg-slate-50'}`}>
                     日程達成率
                  </button>
                  <button onClick={() => { setReportType('DESIGN_ACHIEVEMENT'); if (currentUser.role === 'ADMIN') setTargetUserId('ALL'); }} className={`px-3 py-2 rounded-lg text-sm text-left flex items-center gap-2 ${reportType === 'DESIGN_ACHIEVEMENT' ? 'bg-indigo-50 text-indigo-700 font-bold' : 'text-slate-600 hover:bg-slate-50'}`}>
                     設計成功率
                  </button>
                  <button onClick={() => { setReportType('DESIGN_CHANGE_ACHIEVEMENT'); if (currentUser.role === 'ADMIN') setTargetUserId('ALL'); }} className={`px-3 py-2 rounded-lg text-sm text-left flex items-center gap-2 ${reportType === 'DESIGN_CHANGE_ACHIEVEMENT' ? 'bg-orange-50 text-orange-700 font-bold' : 'text-slate-600 hover:bg-slate-50'}`}>
                     設計變更次數統計
                  </button>
                  <button onClick={() => { setReportType('ALL_TASKS'); if (currentUser.role === 'ADMIN') setTargetUserId('ALL'); }} className={`px-3 py-2 rounded-lg text-sm text-left flex items-center gap-2 ${reportType === 'ALL_TASKS' ? 'bg-slate-100 text-slate-800 font-bold' : 'text-slate-600 hover:bg-slate-50'}`}>
                     全部任務明細 (All)
                  </button>
               </div>
            </div>
          </div>
          
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-400 uppercase">日期範圍</label>
            <div className="flex items-center justify-between bg-slate-50 p-2 rounded-lg border border-slate-200">
               <button onClick={() => shiftDate('prev')} className="p-1 hover:bg-white rounded shadow-sm text-slate-500">
                 <ArrowRightLeft className="w-4 h-4 rotate-180" />
               </button>
               <span className="text-sm font-medium text-slate-700">
                  {reportType === 'DAILY' && selectedDate.toLocaleDateString()}
                  {reportType === 'WEEKLY' && `週次 ${selectedDate.toLocaleDateString()}`}
                  {(reportType === 'MONTHLY' || reportType === 'SCHEDULE_ACHIEVEMENT' || reportType === 'DESIGN_ACHIEVEMENT' || reportType === 'DESIGN_CHANGE_ACHIEVEMENT' || reportType === 'ALL_TASKS') && `${selectedDate.getFullYear()}年 ${selectedDate.getMonth() + 1}月`}
               </span>
               <button onClick={() => shiftDate('next')} className="p-1 hover:bg-white rounded shadow-sm text-slate-500">
                 <ArrowRightLeft className="w-4 h-4" />
               </button>
            </div>
          </div>
          
          {(reportType === 'SCHEDULE_ACHIEVEMENT' || reportType === 'ALL_TASKS') && (
            <div className="space-y-2 animate-in fade-in slide-in-from-left-2 duration-300">
              <label className="text-xs font-bold text-slate-400 uppercase">篩選任務類別</label>
              <select 
                className="w-full p-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500"
                value={targetCategoryId}
                onChange={(e) => setTargetCategoryId(e.target.value)}
              >
                <option value="ALL">📂 全部類別 (All)</option>
                <hr />
                {categories.map(c => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </select>
            </div>
          )}

          {currentUser.role === 'ADMIN' && (
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-400 uppercase">選擇人員 / 範圍</label>
              <select 
                className="w-full p-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500"
                value={targetUserId}
                onChange={(e) => setTargetUserId(e.target.value)}
              >
                <option value="ALL" className="font-bold">👥 所有成員 (全體彙整)</option>
                <hr />
                {users.filter(u => u.role !== 'ADMIN').map(u => (
                  <option key={u.id} value={u.id}>{u.name} ({u.employeeId})</option>
                ))}
              </select>
            </div>
          )}
          
          <div className="pt-4 border-t border-slate-100 space-y-2">
             <Button onClick={handleCopy} variant="secondary" className="w-full">
               <Tag className="w-4 h-4" /> 複製預覽文字
             </Button>
             <Button onClick={handleDownload} className="w-full bg-emerald-600 hover:bg-emerald-700 text-white shadow-emerald-200">
               <Tag className="w-4 h-4" /> 下載 Excel (.xls)
             </Button>
          </div>
        </div>

        <div className="flex-1 bg-slate-50 rounded-xl border border-slate-200 p-4 overflow-hidden flex flex-col">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-bold text-slate-700 flex items-center gap-2">
              <ScrollText className="w-4 h-4" /> 報表預覽 (自動生成)
            </h3>
            {reportType !== 'SCHEDULE_ACHIEVEMENT' && reportType !== 'DESIGN_ACHIEVEMENT' && reportType !== 'DESIGN_CHANGE_ACHIEVEMENT' && reportType !== 'ALL_TASKS' && (
              <span className="text-xs bg-white px-2 py-1 rounded border border-slate-200 text-slate-500">
                {reportData?.isTeamReport ? '團隊總時數: ' : '總時數: '}
                <span className="font-bold text-slate-900">{reportData?.grandTotalTeamHours}h</span>
              </span>
            )}
          </div>
          <div className="flex-1 overflow-y-auto bg-white border border-slate-200 rounded-lg p-4 shadow-sm">
             <pre className="whitespace-pre-wrap font-mono text-sm text-slate-700 leading-relaxed">
               {reportText}
             </pre>
          </div>
        </div>
      </div>
    </Modal>
  );
};
